package com.example.savepass;

public class State {

    private String name_account;
    private int image;

    public State(String name_account, int image) {
        this.name_account = name_account;
        this.image = image;
    }

    public String getName() {
        return this.name_account;
    }

    public void setName(String name) {
        this.name_account = name;
    }

    public int getImageResource() {
        return this.image;
    }

    public void setImageResource(int image) {
        this.image = image;
    }
}