package com.example.savepass;

import android.annotation.SuppressLint;
import android.content.Context;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class FragmentListOfIcon extends Fragment implements View.OnTouchListener {
    private RecyclerView recyclerView;
    public EditText edit_search_icon;
    private ImageView loupe_ico_icon;
    private ConstraintLayout layout;
    private CoordinatorLayout coordinatorLayout;

    private File internalStorage;
    private FileNameHelper fileName;
    private List<State> states = new ArrayList();
    private List<State> statesSearch = new ArrayList();

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_list_of_icon, container, false);

        view.setOnTouchListener(this);

        internalStorage = Objects.requireNonNull(getActivity()).getFilesDir();
        fileName = new FileNameHelper();

        recyclerView = view.findViewById(R.id.fr_recyclerView_icon);
        recyclerView.setOnTouchListener(this);
        edit_search_icon = view.findViewById(R.id.fr_edit_search_icon);
        loupe_ico_icon = view.findViewById(R.id.fr_loupe_ico_icon);
        layout = view.findViewById(R.id.fr_list_icon_activity);
        coordinatorLayout = view.findViewById(R.id.fr_coordinator_layout);

        getActivity().findViewById(R.id.fragment_navigation_menu).setVisibility(View.GONE);

        edit_search_icon.clearFocus();

        loupe_ico_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                new KeyBoardHelper().KeyBoardHide(getActivity(), edit_search_icon);
            }
        });

        edit_search_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
            }
        });

        edit_search_icon.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();

                if (edit_search_icon.length() > 0)
                    setInitialDataForSearch(edit_search_icon.getText().toString());
                else
                    setInitialData();
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edit_search_icon.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean focused) {
                InputMethodManager keyboard = (InputMethodManager) Objects.requireNonNull(getActivity())
                        .getSystemService(Context.INPUT_METHOD_SERVICE);
                if (focused)
                    keyboard.showSoftInput(edit_search_icon, 0);
                else {
                    keyboard.hideSoftInputFromWindow(edit_search_icon.getWindowToken(), 0);
                    edit_search_icon.clearFocus();
                }
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Objects.requireNonNull(getActivity()).findViewById(R.id.fragment_navigation_menu).setVisibility(View.GONE);

        setInitialDataIcon();
        setInitialData();

        try {
            HashMap hashMap = new ObjectStreamHelper()
                    .ObjectInputStream(new File(internalStorage, fileName.getFile_name_settings()));

            int select = 1;

            if (hashMap.get("theme") != null)
                select = (int) hashMap.get("theme");

            switch (select) {
                case 1:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.first_gradient);
                    break;
                case 2:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.second_gradient);
                    break;
                case 3:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.third_gradient);
                    break;
                case 4:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.four_gradient);
                    break;
                case 5:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.five_gradient);
                    break;
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    private void setInitialData() {
        try {
            recyclerView.setAdapter(new RecyclerViewAdapter(FragmentListOfIcon.this,
                    R.layout.patern_recycler_view_icon, states));
            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    private void setInitialDataForSearch(String editSearchText) {
        try {
            statesSearch.clear();
            for (int i = 0; i < states.size(); i++) {
                if (states.get(i).getName().contains(editSearchText.toLowerCase())) {
                    statesSearch.add(new State(states.get(i).getName(), states.get(i).getImageResource()));
                }
            }
            recyclerView.setAdapter(new RecyclerViewAdapter(FragmentListOfIcon.this,
                    R.layout.patern_recycler_view_icon, statesSearch));
            recyclerView.setLayoutManager(new LinearLayoutManager(getActivity()));
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    public List<State> setInitialDataIcon() {
        states.add(new State("other", R.drawable.ic_security));
        states.add(new State("apple", R.drawable.ic_apple));
        states.add(new State("huawei", R.drawable.ic_huawei));
        states.add(new State("payoneer", R.drawable.ic_payoneer));
        states.add(new State("website", R.drawable.ic_website));
        states.add(new State("slack", R.drawable.ic_slack));
        states.add(new State("instagram", R.drawable.ic_instagram));
        states.add(new State("vkontakte", R.drawable.ic_vk));
        states.add(new State("behance", R.drawable.ic_behance));
        states.add(new State("pinterest", R.drawable.ic_pinterest));
        states.add(new State("dribbble", R.drawable.ic_dribbble));
        states.add(new State("gmail", R.drawable.ic_gmail));
        states.add(new State("google", R.drawable.ic_google));
        states.add(new State("google plus", R.drawable.ic_google_plus));
        states.add(new State("google photo", R.drawable.ic_google_photo));
        states.add(new State("google drive", R.drawable.ic_google_drive));
        states.add(new State("upwork", R.drawable.ic_upwork));
        states.add(new State("amazon", R.drawable.ic_amazon));
        states.add(new State("dropbox", R.drawable.ic_dropbox));
        states.add(new State("facebook", R.drawable.ic_facebook));
        states.add(new State("snapchat", R.drawable.ic_snapchat));
        states.add(new State("linkedin", R.drawable.ic_linkedin));
        states.add(new State("telegram", R.drawable.ic_telegram));
        states.add(new State("twitter", R.drawable.ic_twitter));
        states.add(new State("whatsapp", R.drawable.ic_whatsapp));
        states.add(new State("viber", R.drawable.ic_viber));
        states.add(new State("yandex disk", R.drawable.ic_yandexdisk));
        states.add(new State("docker", R.drawable.ic_docker));
        states.add(new State("github", R.drawable.ic_github));
        states.add(new State("zeplin", R.drawable.ic_zeplin));
        states.add(new State("kufar", R.drawable.ic_kufar));
        states.add(new State("skype", R.drawable.ic_skype));
        states.add(new State("youtube", R.drawable.ic_youtube));
        states.add(new State("messenger", R.drawable.ic_messenger));
        states.add(new State("twitter", R.drawable.ic_twitter));
        states.add(new State("twitch", R.drawable.ic_twitch));
        states.add(new State("team viewer", R.drawable.ic_team_viewer));
        states.add(new State("unity", R.drawable.ic_unity));
        states.add(new State("flaticon", R.drawable.ic_flaticon));
        states.add(new State("tumblr", R.drawable.ic_tumblr));
        states.add(new State("hangouts", R.drawable.ic_hangouts));
        states.add(new State("wildberries", R.drawable.ic_wildberries));
        states.add(new State("voka tv", R.drawable.ic_voka_tv));
        states.add(new State("uber", R.drawable.ic_uber));
        states.add(new State("trello", R.drawable.ic_trello));
        states.add(new State("tandem", R.drawable.ic_tandem));
        states.add(new State("mail", R.drawable.ic_mail));
        states.add(new State("joom", R.drawable.ic_joom));
        states.add(new State("habr", R.drawable.ic_habr));
        states.add(new State("deezer", R.drawable.ic_deezer));
        states.add(new State("creative-cloud", R.drawable.ic_creative_cloud));
        states.add(new State("genymotion", R.drawable.ic_genymotion));
        states.add(new State("workbench", R.drawable.ic_workbench));
        states.add(new State("react", R.drawable.ic_react));
        states.add(new State("classmates", R.drawable.ic_classmates));
        states.add(new State("badoo", R.drawable.ic_badoo));
        states.add(new State("aliexpress", R.drawable.ic_aliexpress));
        states.add(new State("21vek", R.drawable.ic_21_vek));
        states.add(new State("4pda", R.drawable.ic_4pda));
        states.add(new State("blogger", R.drawable.ic_blogger));
        states.add(new State("delicious", R.drawable.ic_delicious));
        states.add(new State("deviantart", R.drawable.ic_deviantart));
        states.add(new State("digg", R.drawable.ic_digg));
        states.add(new State("dislike", R.drawable.ic_dislike));
        states.add(new State("envato", R.drawable.ic_envato));
        states.add(new State("flickr", R.drawable.ic_flickr));
        states.add(new State("forrst", R.drawable.ic_forrst));
        states.add(new State("foursquare", R.drawable.ic_foursquare));
        states.add(new State("happy", R.drawable.ic_happy));
        states.add(new State("kickstarter", R.drawable.ic_kickstarter));
        states.add(new State("lastfm", R.drawable.ic_lastfm));
        states.add(new State("like", R.drawable.ic_like));
        states.add(new State("myspace", R.drawable.ic_myspace));
        states.add(new State("path", R.drawable.ic_path));
        states.add(new State("picasa", R.drawable.ic_picasa));
        states.add(new State("plurk", R.drawable.ic_plurk));
        states.add(new State("reddit", R.drawable.ic_reddit));
        states.add(new State("rss", R.drawable.ic_rss));
        states.add(new State("soundcloud", R.drawable.ic_soundcloud));
        states.add(new State("spotify", R.drawable.ic_spotify));
        states.add(new State("stumbleupon", R.drawable.ic_stumbleupon));
        states.add(new State("viddler", R.drawable.ic_viddler));
        states.add(new State("vimeo", R.drawable.ic_vimeo));
        states.add(new State("vine", R.drawable.ic_vine));
        states.add(new State("wattpad", R.drawable.ic_wattpad));
        states.add(new State("wordpress", R.drawable.ic_wordpress));
        states.add(new State("xing", R.drawable.ic_xing));
        states.add(new State("yahoo", R.drawable.ic_yahoo));
        states.add(new State("zootool", R.drawable.ic_zootool));
        return states;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        new KeyBoardHelper().KeyBoardHide(v, event, getActivity(), edit_search_icon);
        return false;
    }
}