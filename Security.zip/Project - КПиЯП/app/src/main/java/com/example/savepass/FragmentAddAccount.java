package com.example.savepass;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.SeekBar;
import android.widget.TextView;

import java.io.File;
import java.util.HashMap;
import java.util.Objects;
import java.util.Random;

public class FragmentAddAccount extends Fragment implements View.OnTouchListener {
    private ImageView btn_generation_pass, eye_pass_sign, change_photo;
    private EditText edit_login, edit_pass;
    private SeekBar generation_pass;
    private TextView low_text, hard_text, message_about_error;
    private Button btn_save;
    private ConstraintLayout layout;
    private CoordinatorLayout coordinatorLayout;

    private File file;
    private FileNameHelper fileName;
    private File internalStorage;

    private HashMapDirectory hashMapDirectory;

    private File fileIcon;
    private HashMapDirectory hashMapDirectoryIcon;

    private String colorGreen = "#6DF38E";
    private String colorRed = "#F14337";
    private String colorWhite = "#FFFFFF";

    private boolean fragmentVisible = false;
    private boolean checkPassLength = true;
    private boolean checkLoginLength = true;
    private boolean btn_generation_pass_click = false;
    private Intent intentSave;
    public static boolean getSaveState = false;
    public static Bundle getBundle;

    char[] login_symbols = {' ', '#', '^', ':', ';', '/', '?'
            , '\"', '&', '*', '(', ')', ',', '+', '=', '<', '>', '{', '}', '|'};

    public static boolean changeState = false;
    private boolean checkLogin = true;
    private boolean checkPass = true;
    private long timeForClose = 5000;
    private long timeForClear = 2000;
    private CountDownTimer countDownTimer;
    private CountDownTimer countDownTimerMessage;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_add_account, container, false);

        internalStorage = Objects.requireNonNull(getActivity()).getFilesDir();
        fileName = new FileNameHelper();

        intentSave = getActivity().getIntent();
        getBundle = getArguments();

        layout = view.findViewById(R.id.fr_add_activity);

        coordinatorLayout = view.findViewById(R.id.fr_coordinator_layout);

        change_photo = view.findViewById(R.id.fr_change_photo);

        view.setOnTouchListener(this);

        low_text = view.findViewById(R.id.fr_low_text);

        hard_text = view.findViewById(R.id.fr_hard_text);

        message_about_error = view.findViewById(R.id.fr_message_about_error);

        edit_login = view.findViewById(R.id.fr_edit_login);

        edit_pass = view.findViewById(R.id.fr_edit_pass);

        btn_generation_pass = view.findViewById(R.id.fr_btn_generation_pass);

        generation_pass = view.findViewById(R.id.fr_generation_pass);

        btn_save = view.findViewById(R.id.fr_btn_save);

        eye_pass_sign = view.findViewById(R.id.fr_eye_pass_sign);

        String save;

        if (intentSave.getStringExtra("login") != null && intentSave.getStringExtra("pass") != null) {
            save = intentSave.getStringExtra("login");

            if (!save.isEmpty() && save != null) {
                edit_login.setText(intentSave.getStringExtra("login"));
                edit_pass.setText(intentSave.getStringExtra("pass"));
                change_photo.setImageResource(intentSave.getIntExtra
                        (fileName.getIntentExtraIcon(), R.drawable.ic_security));
                changeState = intentSave.getBooleanExtra("changeState", false);
            }
        }

        change_photo.setOnClickListener(
                new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        try {
                            ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();

                            if (edit_login.isFocused()) {
                                new KeyBoardHelper().KeyBoardHide(getActivity(), edit_login);
                            }
                            if (edit_pass.isFocused()) {
                                new KeyBoardHelper().KeyBoardHide(getActivity(), edit_pass);
                            }
                        } catch (Exception e) {
                            Log.println(0, "", e.getMessage());
                        }

                        try {
                            file = new File(internalStorage, fileName.getFile_name_save_fields());
                            hashMapDirectory = new HashMapDirectory();

                            SaveFields(file, hashMapDirectory, edit_login, edit_pass);

                            Fragment fragment = new FragmentListOfIcon();
                            Bundle bundle = new Bundle();

                            if (changeState) {
                                bundle.putBoolean("changeState", true);
                                bundle.putString(fileName.getIntentExtraName(), edit_login.getText().toString());
                            }

                            fragment.setArguments(bundle);

                            if (getFragmentManager() != null) {
                                getFragmentManager().beginTransaction()
                                        .replace(R.id.fragment_list_account, fragment)
                                        .addToBackStack(null)
                                        .commit();
                            }
                        } catch (Exception e) {
                            e.printStackTrace();
                        }
                    }
                });

        eye_pass_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();

                if (edit_pass.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    edit_pass.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_pass_sign.setImageResource(R.drawable.ic_eye_pass_not_look);
                    countDownTimer.cancel();
                } else {
                    edit_pass.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    eye_pass_sign.setImageResource(R.drawable.ic_eye_pass_look);
                    TimerForPass();
                }
                edit_pass.setSelection(edit_pass.getText().length());
            }
        });

        edit_login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
            }
        });

        edit_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
            }
        });

        edit_login.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();

                checkLogin = true;
                int index;
                for (char Tchar : login_symbols) {
                    index = edit_login.getText().toString().indexOf(Tchar);
                    if (index != -1) {
                        checkLogin = false;
                        break;
                    } else
                        checkLogin = true;
                }

                if (checkLogin) {
                    message_about_error.setText("");
                    edit_login.getBackground().setColorFilter
                            (Color.parseColor(colorWhite),
                                    PorterDuff.Mode.SRC_ATOP);

                    if (s.length() > 60) {
                        message_about_error.setText(getResources().getString(R.string.count_char_in_login_exceeded));
                        checkLoginLength = false;
                        edit_login.getBackground().setColorFilter
                                (Color.parseColor(colorRed),
                                        PorterDuff.Mode.SRC_ATOP);
                    } else {
                        message_about_error.setText("");
                        checkLoginLength = true;
                        edit_login.getBackground().setColorFilter
                                (Color.parseColor(colorWhite),
                                        PorterDuff.Mode.SRC_ATOP);
                    }
                } else {
                    message_about_error.setText(getResources().getString(R.string.login_contains_prohibited_char));
                    edit_login.getBackground().setColorFilter
                            (Color.parseColor(colorRed),
                                    PorterDuff.Mode.SRC_ATOP);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        edit_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();

                checkPass = true;

                if (s.length() > 0) {
                    eye_pass_sign.setVisibility(View.VISIBLE);
                } else {
                    eye_pass_sign.setVisibility(View.GONE);
                }

                int index;
                index = edit_pass.getText().toString().indexOf(' ');
                if (index != -1)
                    checkPass = false;
                else
                    checkPass = true;


                if (checkPass) {
                    message_about_error.setText("");
                    edit_pass.getBackground().setColorFilter
                            (Color.parseColor(colorWhite),
                                    PorterDuff.Mode.SRC_ATOP);
                    if (s.length() > 60) {
                        message_about_error.setText(getResources()
                                .getString(R.string.count_char_in_password_exceeded));
                        checkPassLength = false;
                        edit_pass.getBackground().setColorFilter
                                (Color.parseColor(colorRed),
                                        PorterDuff.Mode.SRC_ATOP);
                    } else {
                        message_about_error.setText("");
                        checkPassLength = true;
                        edit_pass.getBackground().setColorFilter
                                (Color.parseColor(colorWhite),
                                        PorterDuff.Mode.SRC_ATOP);
                    }
                } else {
                    message_about_error.setText(getResources()
                            .getString(R.string.password_contains_prohibited_char));
                    edit_pass.getBackground().setColorFilter
                            (Color.parseColor(colorRed),
                                    PorterDuff.Mode.SRC_ATOP);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btn_generation_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();

                new KeyBoardHelper().KeyBoardHide(getActivity(), edit_login);
                new KeyBoardHelper().KeyBoardHide(getActivity(), edit_pass);

                if (btn_generation_pass_click) {
                    btn_generation_pass.setImageResource(R.drawable.ic_off);
                    generation_pass.setProgress(1);
                    generation_pass.setVisibility(View.GONE);
                    low_text.setVisibility(View.GONE);
                    hard_text.setVisibility(View.GONE);
                    btn_generation_pass_click = false;
                } else {
                    btn_generation_pass.setImageResource(R.drawable.ic_on);
                    generation_pass.setVisibility(View.VISIBLE);
                    low_text.setVisibility(View.VISIBLE);
                    hard_text.setVisibility(View.VISIBLE);
                    btn_generation_pass_click = true;
                }
            }
        });

        btn_save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();

                try {
                    File saveState = new File(internalStorage, fileName.getFile_name_save_state());
                    int iconId = R.drawable.ic_security;
                    if (saveState.exists()) {
                        HashMap sState = new ObjectStreamHelper().ObjectInputStream(saveState);
                        if (Objects.requireNonNull(sState.get("resource")).toString() != null)
                            iconId = Integer.valueOf(Objects.requireNonNull(sState.get("resource")).toString());
                        else
                            iconId = getBundle.getInt(fileName.getIntentExtraIcon(), R.drawable.ic_security);
                    }

                    if (!edit_login.getText().toString().equals("") && !edit_pass.getText().toString().equals("")
                            && checkLogin && checkLoginLength && checkPass && checkPassLength && !changeState) {
                        Decrypt(intentSave);
                        file = new File(internalStorage, fileName.getFile_name_sys_ac());
                        fileIcon = new File(internalStorage, fileName.getFile_name_sys_ic());

                        if (file.length() > 0 && file.exists()) {
                            //Message("Length > 0");

                            HashMap map = new ObjectStreamHelper().ObjectInputStream(file);
                            HashMap mapIcon = new ObjectStreamHelper().ObjectInputStream(fileIcon);

                            hashMapDirectory = new HashMapDirectory();
                            hashMapDirectoryIcon = new HashMapDirectory();

                            if (hashMapDirectory.InputAccount(map, edit_login.getText().toString(), edit_pass.getText().toString())) {
                                new ObjectStreamHelper().ObjectOutputStream(hashMapDirectory, file);

                                String intentS = "";

                                if (getBundle != null)
                                    hashMapDirectoryIcon.InputAccount(mapIcon, edit_login.getText().toString(),
                                            getBundle.getInt(fileName.getIntentExtraIcon(), R.drawable.ic_security));
                                else if (getSaveState) {
                                    hashMapDirectoryIcon.InputAccount(mapIcon, edit_login.getText().toString(),
                                            iconId);
                                } else if (intentSave.getStringExtra("login") != null) {
                                    intentS = intentSave.getStringExtra("login");
                                    if (!intentS.equals("")) {
                                        hashMapDirectoryIcon.InputAccount(mapIcon, edit_login.getText().toString(),
                                                intentSave.getIntExtra(fileName.getIntentExtraIcon(), R.drawable.ic_security));
                                    }
                                } else
                                    hashMapDirectoryIcon.InputAccount(mapIcon, edit_login.getText().toString(),
                                            R.drawable.ic_security);

                                new ObjectStreamHelper().ObjectOutputStreamIcon(hashMapDirectoryIcon, fileIcon);

                                edit_login.setText("");
                                edit_pass.setText("");

                                CorrectData(edit_login, edit_pass);

                                intentSave.removeExtra("login");
                                intentSave.removeExtra("pass");
                                intentSave.removeExtra(fileName.getIntentExtraIcon());
                                intentSave.removeExtra(fileName.getIntentExtraName());
                                intentSave.removeExtra("changeState");

                                generation_pass.setProgress(1);
                                message_about_error.setText(getResources().getString(R.string.saved_successfully));
                                message_about_error.setTextColor(getResources().getColor(R.color.colorGreen));
                                TimerMessage();
                                Thread threadEncrypt = new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Encrypt(intentSave);
                                    }
                                });

                                threadEncrypt.start();
                            } else {
                                message_about_error.setText(getResources().getString(R.string.such_login_exists));
                                EditColorRed(edit_login);
                            }
                        } else {
                            //Message("Length == 0");

                            hashMapDirectory = new HashMapDirectory();
                            hashMapDirectoryIcon = new HashMapDirectory();

                            if (hashMapDirectory.InputAccount(new HashMap(), edit_login.getText().toString(),
                                    edit_pass.getText().toString())) {
                                new ObjectStreamHelper().ObjectOutputStream(hashMapDirectory, file);

                                String intentS = "";

                                if (getBundle != null)
                                    hashMapDirectoryIcon.InputAccount(new HashMap(), edit_login.getText().toString(),
                                            getBundle.getInt(fileName.getIntentExtraIcon(), R.drawable.ic_security));
                                else if (getSaveState) {
                                    hashMapDirectoryIcon.InputAccount(new HashMap(), edit_login.getText().toString(),
                                            iconId);
                                } else if (intentSave.getStringExtra("login") != null) {
                                    intentS = intentSave.getStringExtra("login");
                                    if (!intentS.equals("")) {
                                        hashMapDirectoryIcon.InputAccount(new HashMap(), edit_login.getText().toString(),
                                                intentSave.getIntExtra(fileName.getIntentExtraIcon(), R.drawable.ic_security));
                                    }
                                } else
                                    hashMapDirectoryIcon.InputAccount(new HashMap(), edit_login.getText().toString(),
                                            R.drawable.ic_security);


                                new ObjectStreamHelper().ObjectOutputStreamIcon(hashMapDirectoryIcon, fileIcon);

                                edit_login.setText("");
                                edit_pass.setText("");

                                intentSave.removeExtra("login");
                                intentSave.removeExtra("pass");
                                intentSave.removeExtra(fileName.getIntentExtraIcon());
                                intentSave.removeExtra(fileName.getIntentExtraName());
                                intentSave.removeExtra("changeState");

                                generation_pass.setProgress(1);
                                CorrectData(edit_login, edit_pass);
                                message_about_error.setText(getResources().getString(R.string.saved_successfully));
                                message_about_error.setTextColor(getResources().getColor(R.color.colorGreen));
                                TimerMessage();
                                Thread threadEncrypt = new Thread(new Runnable() {
                                    @Override
                                    public void run() {
                                        Encrypt(intentSave);
                                    }
                                });

                                threadEncrypt.start();
                            } else {
                                message_about_error.setText(getResources().getString(R.string.such_login_exists));
                                EditColorRed(edit_login);
                            }
                        }
                    } else if (!edit_login.getText().toString().equals("") && !edit_pass.getText().toString().equals("")
                            && checkLogin && checkLoginLength && checkPass && checkPassLength && changeState) {
                        Decrypt(intentSave);
                        file = new File(internalStorage, fileName.getFile_name_sys_ac());
                        HashMap map = new ObjectStreamHelper().ObjectInputStream(file);

                        fileIcon = new File(internalStorage, fileName.getFile_name_sys_ic());
                        HashMap mapIcon = new ObjectStreamHelper().ObjectInputStream(fileIcon);

                        hashMapDirectory = new HashMapDirectory();

                        hashMapDirectoryIcon = new HashMapDirectory();

                        if (getSaveState) {
                            hashMapDirectory.ChangeAccount(map, getBundle.getString(fileName.getIntentExtraName())
                                    , edit_login.getText().toString(), edit_pass.getText().toString());
                            hashMapDirectoryIcon.ChangeAccount(mapIcon, getBundle.getString(fileName.getIntentExtraName())
                                    , edit_login.getText().toString(),
                                    iconId);
                        } else if (getBundle != null) {
                            hashMapDirectory.ChangeAccount(map, getBundle.getString(fileName.getIntentExtraName())
                                    , edit_login.getText().toString(), edit_pass.getText().toString());
                            hashMapDirectoryIcon.ChangeAccount(mapIcon, getBundle.getString(fileName.getIntentExtraName())
                                    , edit_login.getText().toString(),
                                    getBundle.getInt(fileName.getIntentExtraIcon(), R.drawable.ic_security));
                        } else {
                            hashMapDirectory.ChangeAccount(map, intentSave.getStringExtra(fileName.getIntentExtraName())
                                    , edit_login.getText().toString(), edit_pass.getText().toString());
                            hashMapDirectoryIcon.ChangeAccount(mapIcon, intentSave.getStringExtra(fileName.getIntentExtraName())
                                    , edit_login.getText().toString(),
                                    intentSave.getIntExtra(fileName.getIntentExtraIcon(), R.drawable.ic_security));
                        }

                        new ObjectStreamHelper().ObjectOutputStream(hashMapDirectory, file);

                        new ObjectStreamHelper().ObjectOutputStreamIcon(hashMapDirectoryIcon, fileIcon);

                        edit_login.setText("");
                        edit_pass.setText("");

                        intentSave.removeExtra("login");
                        intentSave.removeExtra("pass");
                        intentSave.removeExtra(fileName.getIntentExtraIcon());
                        intentSave.removeExtra(fileName.getIntentExtraName());
                        intentSave.removeExtra("changeState");

                        changeState = false;

                        generation_pass.setProgress(1);
                        CorrectData(edit_login, edit_pass);
                        message_about_error.setText(getResources().getString(R.string.changed_and_saved_successfully));
                        message_about_error.setTextColor(getResources().getColor(R.color.colorGreen));

                        Thread threadEncrypt = new Thread(new Runnable() {
                            @Override
                            public void run() {
                                Encrypt(intentSave);
                            }
                        });

                        getBundle.clear();
                        Log.println(0, "", String.valueOf
                                (new File(internalStorage, fileName.getFile_name_save_fields()).delete()));

                        Log.println(0, "", String.valueOf
                                (new File(internalStorage, fileName.getFile_name_save_state()).delete()));

                        threadEncrypt.start();

                        getFragmentManager().beginTransaction()
                                .setCustomAnimations(R.anim.enter_right_to_left, R.anim.exit_right_to_left,
                                        R.anim.enter_left_to_right, R.anim.exit_left_to_right)
                                .replace(R.id.fragment_list_account, new FragmentListOfAccount())
                                .addToBackStack(null)
                                .commit();
                    } else {
                        ErrorNotification(edit_login, edit_pass, checkLogin, checkPass, checkLoginLength, checkPassLength);
                    }
                } catch (Throwable e) {
                    e.printStackTrace();
                }
            }
        });

        generation_pass.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override
            public void onProgressChanged(SeekBar seekBar, int progress, boolean fromUser) {
                ((ActivityApp) getActivity()).RestartTimer();

                String stroka = "";

                if (progress < 2) {
                    stroka = "";
                    edit_pass.setText(stroka);
                } else {
                    for (int i = 1; i < seekBar.getMax(); i++) {
                        stroka = "";
                        stroka += RandomChar(progress) + RandomChisel(progress);
                    }
                    edit_pass.setText(stroka);
                    edit_pass.setSelection(edit_pass.getText().length());
                }
            }

            @Override
            public void onStartTrackingTouch(SeekBar seekBar) {
            }

            @Override
            public void onStopTrackingTouch(SeekBar seekBar) {
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        savedInstanceState = getArguments();
        fragmentVisible = true;

        FragmentListOfAccount.fragmentVisible = false;

        getSaveState = false;

        DefaultFields(edit_login, edit_pass);

        try {
            HashMap hashMap = new ObjectStreamHelper().ObjectInputStream
                    (new File(internalStorage, fileName.getFile_name_settings()));

            int select = 1;

            if (hashMap.get("theme") != null)
                select = (int) hashMap.get("theme");

            switch (select) {
                case 1:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.first_gradient);
                    break;
                case 2:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.second_gradient);
                    break;
                case 3:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.third_gradient);
                    break;
                case 4:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.four_gradient);
                    break;
                case 5:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.five_gradient);
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }

        try {
            if (intentSave.getStringExtra("login") != null && intentSave.getStringExtra("pass") != null) {
                edit_login.setText(intentSave.getStringExtra("login"));
                edit_pass.setText(intentSave.getStringExtra("pass"));
                change_photo.setImageResource(intentSave.getIntExtra(fileName.getIntentExtraIcon(), R.drawable.ic_security));
            } else
                change_photo.setImageResource(R.drawable.ic_security);

            if (savedInstanceState != null) {
                if (savedInstanceState.getBoolean("clickBtnChange", false)) {
                    changeState = true;
                    Decrypt(intentSave);
                    file = new File(internalStorage, fileName.getFile_name_sys_ac());
                    HashMap m = new ObjectStreamHelper().ObjectInputStream(file);
                    edit_login.setText(savedInstanceState.getString(fileName.getIntentExtraName()));
                    edit_pass.setText(m.get(savedInstanceState.getString(fileName.getIntentExtraName())).toString());
                    change_photo.setImageResource(savedInstanceState.getInt(fileName.getIntentExtraIcon(), R.drawable.ic_security));
                    eye_pass_sign.setVisibility(View.VISIBLE);
                    edit_login.setSelection(edit_login.getText().length());
                    Thread threadEncrypt = new Thread(new Runnable() {
                        @Override
                        public void run() {
                            Encrypt(intentSave);
                        }
                    });
                    threadEncrypt.start();
                }
            }

            File f = new File(internalStorage, fileName.getFile_name_save_state());
            if (f.exists()) {
                HashMap map = new ObjectStreamHelper().ObjectInputStream(f);
                if (map.get("fields").toString() != null) {
                    getSaveState = true;
                    btn_generation_pass.setImageResource(R.drawable.ic_on);
                    change_photo.setImageResource(Integer.valueOf(map.get("resource").toString()));
                    changeState = Boolean.valueOf(map.get("changeState").toString());
                    file = new File(internalStorage, fileName.getFile_name_save_fields());
                    if (file.exists()) {
                        HashMap maps = new ObjectStreamHelper().ObjectInputStream(file);
                        edit_login.setText(maps.get("login").toString());
                        edit_pass.setText(maps.get("pass").toString());
                        Log.println(0, "", String.valueOf(file.delete()));
                    }
                    edit_login.setSelection(edit_login.getText().length());
                }
            }

            if (!btn_generation_pass_click) {
                btn_generation_pass.setImageResource(R.drawable.ic_off);
                generation_pass.setVisibility(View.GONE);
                low_text.setVisibility(View.GONE);
                hard_text.setVisibility(View.GONE);
            }

            if (edit_pass.getText().length() > 0) {
                eye_pass_sign.setVisibility(View.VISIBLE);
            }

            getActivity().findViewById(R.id.fragment_navigation_menu).setVisibility(View.VISIBLE);
            ((ActivityApp) getActivity()).BtnNavigation();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public void onPause() {
        super.onPause();
        fragmentVisible = false;
    }

    private void TimerMessage() {
        countDownTimerMessage = new CountDownTimer(timeForClear, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                if (fragmentVisible) {
                    edit_login.getBackground().setColorFilter
                            (Color.parseColor(colorWhite),
                                    PorterDuff.Mode.SRC_ATOP);
                    edit_pass.getBackground().setColorFilter
                            (Color.parseColor(colorWhite),
                                    PorterDuff.Mode.SRC_ATOP);
                    message_about_error.setText("");
                    message_about_error.setTextColor(getResources().getColor(R.color.colorRed));
                }
            }
        }.start();
    }

    private void TimerForPass() {
        countDownTimer = new CountDownTimer(timeForClose, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                if (edit_pass.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    edit_pass.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_pass_sign.setImageResource(R.drawable.ic_eye_pass_not_look);
                }
                edit_pass.setSelection(edit_pass.getText().length());
            }
        }.start();
    }

    private void SaveFields(File file, HashMapDirectory hashMapDirectory, EditText login, EditText pass) {
        hashMapDirectory.InputAccount("login", login.getText().toString());
        hashMapDirectory.InputAccount("pass", pass.getText().toString());

        new ObjectStreamHelper().ObjectOutputStream(hashMapDirectory, file);
    }

    private void EditColorRed(EditText pole) {
        pole.getBackground().setColorFilter
                (Color.parseColor(colorRed),
                        PorterDuff.Mode.SRC_ATOP);
    }

    private void CorrectData(EditText login, EditText pass) {
        login.getBackground().setColorFilter
                (Color.parseColor(colorGreen),
                        PorterDuff.Mode.SRC_ATOP);
        pass.getBackground().setColorFilter
                (Color.parseColor(colorGreen),
                        PorterDuff.Mode.SRC_ATOP);
    }

    private void DefaultFields(EditText login, EditText pass) {
        login.getBackground().setColorFilter
                (Color.parseColor(colorWhite),
                        PorterDuff.Mode.SRC_ATOP);
        pass.getBackground().setColorFilter
                (Color.parseColor(colorWhite),
                        PorterDuff.Mode.SRC_ATOP);
    }

    private void ErrorNotification(EditText login, EditText pass, boolean checkLogin,
                                   boolean checkPass, boolean checkLoginLength, boolean checkPassLength) {
        if (login.getText().toString().equals("")) {
            login.getBackground().setColorFilter
                    (Color.parseColor(colorRed),
                            PorterDuff.Mode.SRC_ATOP);
            message_about_error.setText(getResources().getString(R.string.login_field_is_empty));
        }

        if (pass.getText().toString().equals("")) {
            pass.getBackground().setColorFilter
                    (Color.parseColor(colorRed),
                            PorterDuff.Mode.SRC_ATOP);
            message_about_error.setText(getResources().getString(R.string.password_field_is_empty));
        }

        if (edit_login.length() > 60) {
            message_about_error.setText(getResources().getString(R.string.count_char_in_login_exceeded));
            checkLoginLength = false;
            edit_login.getBackground().setColorFilter
                    (Color.parseColor(colorRed),
                            PorterDuff.Mode.SRC_ATOP);
        }

        if (edit_pass.length() > 60) {
            message_about_error.setText(getResources().getString(R.string.count_char_in_password_exceeded));
            checkPassLength = false;
            edit_pass.getBackground().setColorFilter
                    (Color.parseColor(colorRed),
                            PorterDuff.Mode.SRC_ATOP);
        }

        if (!checkLogin) {
            message_about_error.setText(getResources().getString(R.string.login_contains_prohibited_char));
            edit_login.getBackground().setColorFilter
                    (Color.parseColor(colorRed),
                            PorterDuff.Mode.SRC_ATOP);
        }

        if (!checkPass) {
            message_about_error.setText(getResources().getString(R.string.password_contains_prohibited_char));
            edit_pass.getBackground().setColorFilter
                    (Color.parseColor(colorRed),
                            PorterDuff.Mode.SRC_ATOP);
        }
    }

    private String RandomChar(int length) {
        Random random = new Random();

        final int alphavit = 'Z' - 'A' + 1;
        StringBuilder rez = new StringBuilder(length);
        while (rez.length() < length) {
            final char charCaseBit = (char) (random.nextInt(2) << 5);
            rez.append((char) (charCaseBit | ('A' + random.nextInt(alphavit))));
        }
        return rez.toString();
    }

    private Integer RandomChisel(int length) {
        Random random = new Random();
        return random.nextInt(length);
    }

    private void Encrypt(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");
        try {
            security.Encrypt(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()));
            File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
            Log.d("RenameFromEncrypt", String.valueOf(fr.renameTo
                    (new File(internalStorage, fileName.getFile_name_sys_ac())))) ;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void Decrypt(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");
        try {
            if (security.Decrypt(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()))) {
                File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
                Log.d("RenameFromDecrypt", String.valueOf(fr.renameTo
                        (new File(internalStorage, fileName.getFile_name_sys_ac())))) ;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        new KeyBoardHelper().KeyBoardHide(v, event, getActivity(), edit_login);
        new KeyBoardHelper().KeyBoardHide(v, event, getActivity(), edit_pass);
        return false;
    }
}