package com.example.savepass;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.Nullable;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.HashMap;

public class AutorizationInApp extends AppCompatActivity implements View.OnTouchListener {
    private Button btn_sign_autorization;
    private ImageView eye_pass_registr;
    private EditText edit_pass;
    private TextView message_error;
    private ConstraintLayout layout;

    private FileNameHelper fileName;
    private File internalStorage;

    private String colorGreen = "#6DF38E";
    private String colorRed = "#F14337";
    private String colorWhite = "#FFFFFF";

    private boolean checkPass = true;
    private boolean checkPassLength = true;
    private long timeForClose = 5000;
    private CountDownTimer countDownTimer;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_autorization_in_app);
        final Security security = new Security();

        internalStorage = getFilesDir();
        fileName = new FileNameHelper();

        //final CheckOnRoot checkOnRoot = new CheckOnRoot();

        //запрет на скриншоты
        getWindow().setFlags(WindowManager.LayoutParams
                .FLAG_SECURE, WindowManager.LayoutParams.FLAG_SECURE);

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        eye_pass_registr = findViewById(R.id.eye_pass_registr);
        edit_pass = findViewById(R.id.edit_pass);
        btn_sign_autorization = findViewById(R.id.btn_sign_autorization);
        message_error = findViewById(R.id.message_error);
        layout = findViewById(R.id.autorization_activity);
        layout.setOnTouchListener(this);

        try {
            HashMap hashMap = new ObjectStreamHelper()
                    .ObjectInputStream(new File(internalStorage,
                            fileName.getFile_name_settings()));

            int select = 1;

            if (hashMap.get("theme") != null)
                select = (int) hashMap.get("theme");

            switch (select) {
                case 1:
                    SetLayoutBackground(layout, R.drawable.first_gradient);
                    break;
                case 2:
                    SetLayoutBackground(layout, R.drawable.second_gradient);
                    break;
                case 3:
                    SetLayoutBackground(layout, R.drawable.third_gradient);
                    break;
                case 4:
                    SetLayoutBackground(layout, R.drawable.four_gradient);
                    break;
                case 5:
                    SetLayoutBackground(layout, R.drawable.five_gradient);
                    break;
            }
        } catch (Exception e) {
            e.getStackTrace();
        }

//        if(checkOnRoot.isDeviceRooted()){
//            message_error.setText("Error: Root rights are present");
//        }
//        else
//        {
//            message_error.setText("");
//        }

        eye_pass_registr.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (edit_pass.getInputType() == InputType
                        .TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    edit_pass.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_pass_registr.setImageResource(R.drawable.ic_eye_pass_not_look);
                    countDownTimer.cancel();
                } else {
                    edit_pass.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    eye_pass_registr.setImageResource(R.drawable.ic_eye_pass_look);
                    TimerForPass();
                }
                edit_pass.setSelection(edit_pass.getText().length());
            }
        });

        edit_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {

                checkPass = true;
                if (s.length() > 0) {
                    eye_pass_registr.setVisibility(View.VISIBLE);
                } else {
                    eye_pass_registr.setVisibility(View.GONE);
                }

                if (edit_pass.getText().toString().contains(" "))
                    checkPass = false;
                else
                    checkPass = true;

                if (checkPass) {
                    message_error.setText("");
                    edit_pass.getBackground().setColorFilter
                            (Color.parseColor(colorWhite),
                                    PorterDuff.Mode.SRC_ATOP);
                    if (s.length() > 45) {
                        message_error.setText(getResources().getString(R.string.count_char_in_password_exceeded));
                        checkPassLength = false;
                        edit_pass.getBackground().setColorFilter
                                (Color.parseColor(colorRed),
                                        PorterDuff.Mode.SRC_ATOP);
                    } else {
                        message_error.setText("");
                        checkPassLength = true;
                        edit_pass.getBackground().setColorFilter
                                (Color.parseColor(colorWhite),
                                        PorterDuff.Mode.SRC_ATOP);
                    }
                } else {
                    message_error.setText(getResources().getString(R.string.password_contains_prohibited_char));
                    edit_pass.getBackground().setColorFilter
                            (Color.parseColor(colorRed),
                                    PorterDuff.Mode.SRC_ATOP);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btn_sign_autorization.setOnClickListener(new View.OnClickListener() {
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {

                if (edit_pass.getText().length() >= 8
                        && checkPass && checkPassLength)// && !checkOnRoot.isDeviceRooted())
                {
                    edit_pass.getBackground().setColorFilter
                            (Color.parseColor(colorGreen),
                                    PorterDuff.Mode.SRC_ATOP);

                    message_error.setText(getResources().getString(R.string.saved_successfully));
                    message_error.setTextColor(getResources().getColor(R.color.colorGreen));

                    HashMapDirectory directory = new HashMapDirectory();

                    try {
                        String p = edit_pass.getText().toString();
                        new ObjectStreamHelper()
                                .ObjectOutputStream(directory,
                                        new File(internalStorage, fileName.getFile_name_sys_ac()));
                        new ObjectStreamHelper()
                                .ObjectOutputStreamIcon(directory,
                                        new File(internalStorage, fileName.getFile_name_sys_ic()));

//                        /////
//                                             // TEST PROGRAMM
//                        HashMap map_ac = new FragmentAddAccount().ObjectInputStream
//                        (new File(internalStorage, fileName.getFile_name_sys_ac()));
//                        HashMap map_ic = new FragmentAddAccount().ObjectInputStream
//                        (new File(internalStorage, fileName.getFile_name_sys_ic()));
//
//                        for (int i = 0; i < 1500000; i++)
//                        {
//                            map_ac.put(i + "SomeName", i);
//                            map_ic.put(i + "SomeName", Res(ran.nextInt(20)));
//                        }
//
//                        HashMapDirectory hash = new HashMapDirectory();
//                        hash.stringHashMap = map_ac;
//                        HashMapDirectory hash2 = new HashMapDirectory();
//                        hash2.stringHashMap = map_ic;
//
//                        new FragmentAddAccount().ObjectOutputStream
//                        (hash, new File(internalStorage, fileName.getFile_name_sys_ac()));
//                        new FragmentAddAccount().ObjectOutputStream
//                        (hash2, new File(internalStorage, fileName.getFile_name_sys_ic()));
//                        /////

                        security.Encrypt(
                                p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                                new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                                new File(internalStorage, fileName.getFile_name_sys_iv()));

                        File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
                        if (fr.renameTo(new File(internalStorage, fileName.getFile_name_sys_ac()))) {
                            Intent intent = new Intent(AutorizationInApp.this, ActivityApp.class);
                            intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                            intent.putExtra("p", p);
                            startActivity(intent);
                        }
                    } catch (Exception e) {
                        e.printStackTrace();
                    }
                } else {
//                    if(checkOnRoot.isDeviceRooted())
//                    {
//                        message_error.setText("Error: Root rights are present");
//                    }
//                    else
                    {
                        message_error.setText("");
                        edit_pass.getBackground().setColorFilter
                                (Color.parseColor(colorRed),
                                        PorterDuff.Mode.SRC_ATOP);
                    }
                }
            }
        });
    }

//    static Random ran = new Random();
//
//    private static  int Res(int num)
//    {
//        switch (num)
//        {
//            case 1:
//                return R.drawable.ic_4pda;
//            case 2:
//                return R.drawable.ic_21_vek;
//            case 3:
//                return R.drawable.ic_aliexpress;
//            case 4:
//                return R.drawable.ic_amazon;
//            case 5:
//                return R.drawable.ic_badoo;
//            case 6:
//                return R.drawable.ic_creative_cloud;
//            case 7:
//                return R.drawable.ic_wordpress;
//            case 8:
//                return R.drawable.ic_dropbox;
//            case 9:
//                return R.drawable.ic_behance;
//            case 10:
//                return R.drawable.ic_youtube;
//            case 11:
//                return R.drawable.ic_zootool;
//            case 12:
//                return R.drawable.ic_yandexdisk;
//            case 13:
//                return R.drawable.ic_voka_tv;
//            case 14:
//                return R.drawable.ic_vk;
//            case 15:
//                return R.drawable.ic_uber;
//            case 16:
//                return R.drawable.ic_viddler;
//            case 17:
//                return R.drawable.ic_whatsapp;
//            case 18:
//                return R.drawable.ic_deezer;
//            case 19:
//                return R.drawable.ic_wildberries;
//            case 20:
//                return R.drawable.ic_twitch;
//        }
//        return R.drawable.ic_security;
//    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
    }

    @Override
    protected void onResume() {
        super.onResume();
        executeDelayed();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        executeDelayed();
    }

    private void executeDelayed() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            public void run() {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }
        }, 200);
    }

    @SuppressLint("ObsoleteSdkInt")
    public void SetLayoutBackground(ConstraintLayout layout, int res) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            layout.setBackgroundResource(res);
        }
        switch (res) {
            case R.drawable.first_gradient: {
                SetColorStatusBar(R.color.firstStatusBarColor);
                break;
            }
            case R.drawable.second_gradient: {
                SetColorStatusBar(R.color.secondStatusBarColor);
                break;
            }
            case R.drawable.third_gradient: {
                SetColorStatusBar(R.color.thirdStatusBarColor);
                break;
            }
            case R.drawable.four_gradient: {
                SetColorStatusBar(R.color.fourStatusBarColor);
                break;
            }
            case R.drawable.five_gradient: {
                SetColorStatusBar(R.color.fiveStatusBarColor);
                break;
            }
        }
    }

    private void SetColorStatusBar(int id) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(id));
        }
    }

    public void TimerForPass() {
        countDownTimer = new CountDownTimer(timeForClose, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                if (edit_pass.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    edit_pass.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_pass_registr.setImageResource(R.drawable.ic_eye_pass_not_look);
                }
                edit_pass.setSelection(edit_pass.getText().length());
            }
        }.start();
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        new KeyBoardHelper().KeyBoardHide(this, edit_pass);
        return false;
    }
}