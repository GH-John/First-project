package com.example.savepass;

import android.annotation.TargetApi;
import android.os.Build;
import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.FileOutputStream;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;

import javax.crypto.BadPaddingException;
import javax.crypto.Cipher;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;
import javax.crypto.SecretKeyFactory;
import javax.crypto.spec.PBEKeySpec;
import javax.crypto.spec.SecretKeySpec;
import javax.crypto.spec.IvParameterSpec;

import java.security.spec.InvalidKeySpecException;
import java.security.spec.KeySpec;
import java.util.HashMap;
import java.util.Random;

public class Security {
    private static Random srandom = new Random();

    @TargetApi(Build.VERSION_CODES.KITKAT)
    private SecretKeySpec GenerateKey(String password, File ivFile) throws NoSuchAlgorithmException,
            IOException, InvalidKeySpecException {
        int iterationCount = 8000;
        int keyLength = 256;
        byte[] keyBytes;

        KeySpec keySpec = new PBEKeySpec(password.toCharArray(), LoadIV(ivFile).getIV(), iterationCount, keyLength);
        SecretKeyFactory secretKeyFactory = SecretKeyFactory.getInstance("PBKDF2WithHmacSHA1");
        keyBytes = secretKeyFactory.generateSecret(keySpec).getEncoded();
        return new SecretKeySpec(keyBytes, "AES");
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    private IvParameterSpec GenerateIV(File ivFile) throws IOException {
        byte[] iv = new byte[128 / 8];
        srandom.nextBytes(iv);
        IvParameterSpec ivspec = new IvParameterSpec(iv);

        try (FileOutputStream out = new FileOutputStream(ivFile, false)) {
            out.write(iv);
        }
        return ivspec;
    }

    @TargetApi(Build.VERSION_CODES.O)
    private IvParameterSpec LoadIV(File ivFile) throws IOException {
        FileInputStream fileInputStream = new FileInputStream(ivFile);
        byte[] iv = new byte[fileInputStream.available()];
        fileInputStream.read(iv);

        IvParameterSpec ivspec = new IvParameterSpec(iv);

        fileInputStream.close();
        return ivspec;
    }

    public synchronized void Encrypt(String password, File inFile, File outFile, File ivFile)
            throws NoSuchPaddingException, NoSuchAlgorithmException,
            BadPaddingException, IllegalBlockSizeException,
            IOException, InvalidAlgorithmParameterException,
            InvalidKeyException, InvalidKeySpecException {
        GenerateIV(ivFile);
        Cipher ci = Cipher.getInstance("AES/CBC/PKCS5Padding");
        ci.init(Cipher.ENCRYPT_MODE, GenerateKey(password, ivFile), LoadIV(ivFile));
        processFile(ci, inFile, outFile);
    }

    public synchronized boolean Decrypt(String password, File inFile, File outFile, File ivFile)
            throws NoSuchPaddingException, NoSuchAlgorithmException,
            BadPaddingException, IllegalBlockSizeException,
            IOException, InvalidAlgorithmParameterException,
            InvalidKeyException, InvalidKeySpecException {
        Cipher ci = Cipher.getInstance("AES/CBC/PKCS5Padding");
        ci.init(Cipher.DECRYPT_MODE, GenerateKey(password, ivFile), LoadIV(ivFile));

        if (checkFile(ci, inFile, outFile)) {
            return inFile.delete();
        }
        return false;
    }

    public synchronized boolean DecryptForSign(String password, File inFile, File outFile, File ivFile)
            throws NoSuchPaddingException, NoSuchAlgorithmException,
            BadPaddingException, IllegalBlockSizeException,
            IOException, InvalidAlgorithmParameterException,
            InvalidKeyException, InvalidKeySpecException {
        Cipher ci = Cipher.getInstance("AES/CBC/PKCS5Padding");
        ci.init(Cipher.DECRYPT_MODE, GenerateKey(password, ivFile), LoadIV(ivFile));

        if (checkFile(ci, inFile, outFile)) {
            return outFile.delete();
        }
        return false;
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    private static void processFile(Cipher ci, File inFile, File outFile)
            throws javax.crypto.IllegalBlockSizeException,
            javax.crypto.BadPaddingException,
            java.io.IOException {
        try (FileInputStream in = new FileInputStream(inFile);
             FileOutputStream out = new FileOutputStream(outFile)) {
            byte[] ibuf = new byte[1024];
            int len;
            while ((len = in.read(ibuf)) != -1) {
                byte[] obuf = ci.update(ibuf, 0, len);
                if (obuf != null) out.write(obuf);
            }
            byte[] obuf = ci.doFinal();
            if (obuf != null) out.write(obuf);
        }
        Log.d("inFile - ", String.valueOf(inFile.delete()));
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    private static boolean checkFile(Cipher ci, File inFile, File outFile)
            throws javax.crypto.IllegalBlockSizeException,
            javax.crypto.BadPaddingException,
            java.io.IOException {
        try (FileInputStream in = new FileInputStream(inFile);
             FileOutputStream out = new FileOutputStream(outFile)) {
            byte[] ibuf = new byte[1024];
            int len;
            while ((len = in.read(ibuf)) != -1) {
                byte[] obuf = ci.update(ibuf, 0, len);
                if (obuf != null) out.write(obuf);
            }
            byte[] obuf = ci.doFinal();
            if (obuf != null) out.write(obuf);

            HashMap hashMap = new ObjectStreamHelper().ObjectInputStream(outFile);
            if (hashMap != null) {
                return true;
            }
        }
        return false;
    }
}