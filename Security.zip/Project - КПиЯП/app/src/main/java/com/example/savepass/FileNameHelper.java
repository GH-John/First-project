package com.example.savepass;

public class FileNameHelper
{
    public final String getFile_name_sys_ac()  { return "systemAccount.ser"; }
    public final String getFile_name_sys_ic(){ return "systemIcon.ser"; }
    public final String getFile_name_settings(){ return "settingsSerialize.ser"; }
    public final String getFile_name_sys_iv() {return "ivFile.ser"; }
    public final String getBackup_directory_name(){return "SecurityBackup"; }
    public final String getFile_name_accounts_for_delete() { return "accounts_for_delete.ser"; }
    public final String getFile_name_save_fields() { return "fileFields.ser"; }
    public final String getFile_name_save_state() { return "saveState"; }
    public final String getIntentExtraName() { return "name_account"; }
    public final String getIntentExtraIcon() { return "image_account"; }
}