package com.example.savepass;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Context;
import android.content.Intent;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Handler;
import android.support.annotation.RequiresApi;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.MotionEvent;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.view.inputmethod.InputMethodManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;

import java.io.File;
import java.util.HashMap;

public class SignInMenu extends AppCompatActivity implements View.OnTouchListener {

    private Button button_sign_in;
    private ImageView eye_pass_sign;
    private EditText sign_in_password;
    private ConstraintLayout layout;
    private CoordinatorLayout coordinatorLayout;

    private Intent intentSave;
    private File internalStorage;
    private FileNameHelper fileName;

    private boolean click = false;
    private String colorWhite = "#FFFFFF";
    private static long back_pressed;
    private long timeForClose = 5000;
    private CountDownTimer countDownTimer;

    @SuppressLint("ClickableViewAccessibility")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_sign_in_menu);
        internalStorage = getFilesDir();
        intentSave = getIntent();
        fileName = new FileNameHelper();

        //запрет на скриншоты
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE
                , WindowManager.LayoutParams.FLAG_SECURE);

        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);

        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        layout = findViewById(R.id.sign_activity);
        coordinatorLayout = findViewById(R.id.fr_coordinator_layout);
        layout.setOnTouchListener(this);

        try {
            HashMap hashMap = new ObjectStreamHelper()
                    .ObjectInputStream(new File(internalStorage, fileName.getFile_name_settings()));
            int select = 1;

            if (hashMap.get("theme") != null)
                select = (int) hashMap.get("theme");

            switch (select) {
                case 1:
                    SetFragmentBackground(layout, coordinatorLayout, R.drawable.first_gradient);
                    break;
                case 2:
                    SetFragmentBackground(layout, coordinatorLayout, R.drawable.second_gradient);
                    break;
                case 3:
                    SetFragmentBackground(layout, coordinatorLayout, R.drawable.third_gradient);
                    break;
                case 4:
                    SetFragmentBackground(layout, coordinatorLayout, R.drawable.four_gradient);
                    break;
                case 5:
                    SetFragmentBackground(layout, coordinatorLayout, R.drawable.five_gradient);
                    break;
            }
        } catch (Exception e) {
            e.getStackTrace();
        }

        button_sign_in = findViewById(R.id.button_sign_in);

        sign_in_password = findViewById(R.id.sign_in_password);

        sign_in_password.getBackground().setColorFilter(Color.parseColor(colorWhite),
                PorterDuff.Mode.SRC_ATOP);

        eye_pass_sign = findViewById(R.id.eye_pass_sign);

        eye_pass_sign.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                if (sign_in_password.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    sign_in_password.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_pass_sign.setImageResource(R.drawable.ic_eye_pass_not_look);
                    countDownTimer.cancel();
                } else {
                    sign_in_password.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    eye_pass_sign.setImageResource(R.drawable.ic_eye_pass_look);
                    TimerForPass();
                }
                sign_in_password.setSelection(sign_in_password.getText().length());
            }
        });

        sign_in_password.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
                if (s.length() > 0) {
                    eye_pass_sign.setVisibility(View.VISIBLE);
                } else {
                    eye_pass_sign.setVisibility(View.GONE);
                }
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (s.length() > 0) {
                    eye_pass_sign.setVisibility(View.VISIBLE);
                } else {
                    eye_pass_sign.setVisibility(View.GONE);
                }
            }

            @Override
            public void afterTextChanged(Editable s) {
                if (s.length() > 0) {
                    eye_pass_sign.setVisibility(View.VISIBLE);
                } else {
                    eye_pass_sign.setVisibility(View.GONE);
                }
            }
        });

        button_sign_in.setOnClickListener(new View.OnClickListener() {
            @TargetApi(Build.VERSION_CODES.LOLLIPOP)
            @RequiresApi(api = Build.VERSION_CODES.KITKAT)
            @Override
            public void onClick(View v) {
                try {
                    click = true;
                    if(click) {
                        String p = sign_in_password.getText().toString();
                        if (Decrypt(p)) {
                            click = false;
                            sign_in_password.getBackground().setColorFilter
                                    (Color.parseColor("#6DF38E"),
                                            PorterDuff.Mode.SRC_ATOP);
                            sign_in_password.setText("");

                            if (intentSave.getStringExtra("login") != null && intentSave.getStringExtra("pass") != null) {
                                Intent intent = new Intent(SignInMenu.this, ActivityApp.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                intent.putExtra("login", intentSave.getStringExtra("login"));
                                intent.putExtra("pass", intentSave.getStringExtra("pass"));
                                intent.putExtra("name_account", intentSave.getStringExtra("name_account"));
                                intent.putExtra("image_account", intentSave.getIntExtra("image_account", R.drawable.ic_security));
                                intent.putExtra("changeState", intentSave.getBooleanExtra("changeState", false));
                                intent.putExtra("p", p);
                                startActivity(intent);
                            } else {
                                Intent intent = new Intent(SignInMenu.this, ActivityApp.class);
                                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                                intent.putExtra("p", p);
                                startActivity(intent);
                            }
                        } else {
                            sign_in_password.getBackground().setColorFilter
                                    (Color.parseColor("#F14337"),
                                            PorterDuff.Mode.SRC_ATOP);
                        }
                    }
                } catch (Exception e) {
                    e.getStackTrace();
                }
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        executeDelayed();
    }

    @Override
    public void onBackPressed() {
        if (back_pressed + 2000 > System.currentTimeMillis()) {
            Log.println(0, "", String.valueOf(new File(internalStorage, "saveState").delete()));
            moveTaskToBack(true);
            android.os.Process.killProcess(android.os.Process.myPid());
            System.exit(1);
        } else {
            new OutputMessage().Message(this, "Press once again to exit!");
        }
        back_pressed = System.currentTimeMillis();
    }

    public void TimerForPass() {
        countDownTimer = new CountDownTimer(timeForClose, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                if (sign_in_password.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    sign_in_password.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_pass_sign.setImageResource(R.drawable.ic_eye_pass_not_look);
                }
                sign_in_password.setSelection(sign_in_password.getText().length());
            }
        }.start();
    }

    @SuppressLint("ObsoleteSdkInt")
    public void SetFragmentBackground(ConstraintLayout layout, CoordinatorLayout coordinatorLayout, int res) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            layout.setBackgroundResource(res);
            coordinatorLayout.setBackgroundResource(res);
            switch (res) {
                case R.drawable.first_gradient: {
                    SetColorStatusBar(R.color.firstStatusBarColor);
                    break;
                }
                case R.drawable.second_gradient: {
                    SetColorStatusBar(R.color.secondStatusBarColor);
                    break;
                }
                case R.drawable.third_gradient: {
                    SetColorStatusBar(R.color.thirdStatusBarColor);
                    break;
                }
                case R.drawable.four_gradient: {
                    SetColorStatusBar(R.color.fourStatusBarColor);
                    break;
                }
                case R.drawable.five_gradient: {
                    SetColorStatusBar(R.color.fiveStatusBarColor);
                    break;
                }
            }
        }
    }

    private void SetColorStatusBar(int id) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(id));
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        executeDelayed();
    }

    private void executeDelayed() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            public void run() {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY
                );
            }
        }, 200);
    }

    private boolean Decrypt(String p) {
        Security security = new Security();
        try {
            if (security.DecryptForSign(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv())))
                return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int action = event.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {

            InputMethodManager keyboard = (InputMethodManager) getSystemService(Context.INPUT_METHOD_SERVICE);
            if (sign_in_password.isFocused()) {
                keyboard.hideSoftInputFromWindow(sign_in_password.getWindowToken(), 0);
                sign_in_password.clearFocus();
            }
        }
        return false;
    }
}