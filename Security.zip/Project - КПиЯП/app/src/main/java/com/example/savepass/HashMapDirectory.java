package com.example.savepass;

import java.io.Serializable;
import java.util.HashMap;

public class HashMapDirectory implements Serializable {
    HashMap<String,String> stringHashMap = new HashMap<>();
    HashMap<String,Integer> integerHashMap = new HashMap<>();

    public boolean InputAccount(String identificator, String autentificator) {
        if (!stringHashMap.containsKey(identificator)) {
            stringHashMap.put(identificator, autentificator);
            return true;
        }
        return false;
    }

    public boolean InputAccount(HashMap hashMap, String identificator, String autentificator) {
        if (!hashMap.containsKey(identificator)) {
            hashMap.put(identificator, autentificator);
            stringHashMap = hashMap;
            return true;
        }
        return false;
    }

    public boolean InputAccount(HashMap hashMap, String identificator, Integer autentificator) {
        if (!hashMap.containsKey(identificator)) {
            hashMap.put(identificator, autentificator);
            integerHashMap = hashMap;
            return true;
        }
        return false;
    }

    public void ChangeAccount(HashMap hashMap, String oldIdentificator, String newIdentificator, String autentificator) {
        hashMap.remove(oldIdentificator);
        hashMap.put(newIdentificator, autentificator);
        stringHashMap = hashMap;
    }

    public void ChangeAccount(HashMap hashMap, String oldIdentificator, String newIdentificator, Integer autentificator) {
        hashMap.remove(oldIdentificator);
        hashMap.put(newIdentificator, autentificator);
        integerHashMap = hashMap;
    }

    public void ParametrsSettingApp(String identificator, Integer autentificator) {
        integerHashMap.put(identificator, autentificator);
    }

    public void ParametrsSettingApp(HashMap hashMap, String identificator, Integer autentificator) {
        integerHashMap = hashMap;
        integerHashMap.put(identificator, autentificator);
    }
}