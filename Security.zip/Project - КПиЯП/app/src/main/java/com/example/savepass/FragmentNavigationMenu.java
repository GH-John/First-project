package com.example.savepass;

import android.content.Intent;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import java.io.File;
import java.util.Objects;

public class FragmentNavigationMenu extends Fragment {
    private Intent intentSave;
    private FileNameHelper fileName;

    public Button navigation_add_new_account, navigation_home, navigation_settings;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_navigation_menu, container, false);

        intentSave = Objects.requireNonNull(getActivity()).getIntent();
        fileName = new FileNameHelper();

        navigation_add_new_account = view.findViewById(R.id.navigation_add_new_account);
        navigation_home = view.findViewById(R.id.navigation_home);
        navigation_settings = view.findViewById(R.id.navigation_settings);

        navigation_add_new_account.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                AddNewAccount();
            }
        });

        navigation_home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Home();
            }
        });

        navigation_settings.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Settings();
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        navigation_add_new_account.setBackgroundResource(R.drawable.button_time_style);
        navigation_home.setBackgroundResource(R.drawable.button_navigation_style);
        navigation_settings.setBackgroundResource(R.drawable.button_time_style);
    }

    public void AddNewAccount() {
        Log.d("DeleteSaveState", String.valueOf(new File(Objects.requireNonNull
                (getActivity()).getFilesDir(), "saveState").delete()));
        ((ActivityApp) getActivity()).RestartTimer();
        Fragment f = getActivity().getSupportFragmentManager().findFragmentById(R.id.fragment_list_account);
        if (!(f instanceof FragmentAddAccount)) {
            if (f instanceof FragmentSettings) {
                if (!((ActivityApp) getActivity()).CheckAnimSettings()) {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .setCustomAnimations(R.anim.enter_left_to_right, R.anim.exit_left_to_right,
                                    R.anim.enter_right_to_left, R.anim.exit_right_to_left)
                            .replace(R.id.fragment_list_account, new FragmentAddAccount())
                            .addToBackStack(null)
                            .commit();
                } else {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .replace(R.id.fragment_list_account, new FragmentAddAccount())
                            .addToBackStack(null)
                            .commit();
                }

            }

            if (f instanceof FragmentListOfAccount) {
                if (!((ActivityApp) getActivity()).CheckAnimSettings()) {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .setCustomAnimations(R.anim.enter_left_to_right, R.anim.exit_left_to_right,
                                    R.anim.enter_right_to_left, R.anim.exit_right_to_left)
                            .replace(R.id.fragment_list_account, new FragmentAddAccount())
                            .addToBackStack(null)
                            .commit();
                } else {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .replace(R.id.fragment_list_account, new FragmentAddAccount())
                            .addToBackStack(null)
                            .commit();
                }
            }
        }
    }

    public void Home() {
        Log.d("DeleteSaveState", String.valueOf(new File(Objects.requireNonNull
                (getActivity()).getFilesDir(), "saveState").delete()));
        ((ActivityApp) getActivity()).RestartTimer();
        Fragment f = getActivity().getSupportFragmentManager().findFragmentById(R.id.fragment_list_account);
        if (f instanceof FragmentAddAccount && intentSave.getStringExtra("login") != null) {
            intentSave.removeExtra("login");
            intentSave.removeExtra("pass");
            intentSave.removeExtra(fileName.getIntentExtraIcon());
            intentSave.removeExtra(fileName.getIntentExtraName());
            intentSave.removeExtra("changeState");
            assert getFragmentManager() != null;
            getFragmentManager().beginTransaction()
                    .replace(R.id.fragment_list_account, new FragmentListOfAccount())
                    .addToBackStack(null)
                    .commit();
        } else {
            if (f instanceof FragmentSettings) {
                if (!((ActivityApp) getActivity()).CheckAnimSettings()) {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .setCustomAnimations(R.anim.enter_left_to_right, R.anim.exit_left_to_right,
                                    R.anim.enter_right_to_left, R.anim.exit_right_to_left)
                            .replace(R.id.fragment_list_account, new FragmentListOfAccount())
                            .addToBackStack(null)
                            .commit();
                } else {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .replace(R.id.fragment_list_account, new FragmentListOfAccount())
                            .addToBackStack(null)
                            .commit();
                }
            }

            if (f instanceof FragmentAddAccount) {
                if (!((ActivityApp) getActivity()).CheckAnimSettings()) {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .setCustomAnimations(R.anim.enter_right_to_left, R.anim.exit_right_to_left,
                                    R.anim.enter_left_to_right, R.anim.exit_left_to_right)
                            .replace(R.id.fragment_list_account, new FragmentListOfAccount())
                            .addToBackStack(null)
                            .commit();
                } else {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .replace(R.id.fragment_list_account, new FragmentListOfAccount())
                            .addToBackStack(null)
                            .commit();
                }
            }
        }
    }

    public void Settings() {
        Log.d("DeleteSaveState", String.valueOf(new File(Objects.requireNonNull
                (getActivity()).getFilesDir(), "saveState").delete()));
        ((ActivityApp) getActivity()).RestartTimer();
        Fragment f2 = getActivity().getSupportFragmentManager().findFragmentById(R.id.fragment_list_account);
        if (f2 instanceof FragmentAddAccount && intentSave.getStringExtra("login") != null) {
            intentSave.removeExtra("login");
            intentSave.removeExtra("pass");
            intentSave.removeExtra(fileName.getIntentExtraIcon());
            intentSave.removeExtra(fileName.getIntentExtraName());
            intentSave.removeExtra("changeState");
            assert getFragmentManager() != null;
            getFragmentManager().beginTransaction()
                    .replace(R.id.fragment_list_account, new FragmentSettings())
                    .addToBackStack(null)
                    .commit();
        } else {
            if (f2 instanceof FragmentListOfAccount) {
                if (!((ActivityApp) getActivity()).CheckAnimSettings()) {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .setCustomAnimations(R.anim.enter_right_to_left, R.anim.exit_right_to_left,
                                    R.anim.enter_left_to_right, R.anim.exit_left_to_right)
                            .replace(R.id.fragment_list_account, new FragmentSettings())
                            .addToBackStack(null)
                            .commit();
                } else {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .replace(R.id.fragment_list_account, new FragmentSettings())
                            .addToBackStack(null)
                            .commit();
                }
            }

            if (f2 instanceof FragmentAddAccount) {
                if (!((ActivityApp) getActivity()).CheckAnimSettings()) {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .setCustomAnimations(R.anim.enter_right_to_left, R.anim.exit_right_to_left,
                                    R.anim.enter_left_to_right, R.anim.exit_left_to_right)
                            .replace(R.id.fragment_list_account, new FragmentSettings())
                            .addToBackStack(null)
                            .commit();
                } else {
                    assert getFragmentManager() != null;
                    getFragmentManager().beginTransaction()
                            .replace(R.id.fragment_list_account, new FragmentSettings())
                            .addToBackStack(null)
                            .commit();
                }
            }
        }
    }
}