package com.example.savepass;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Color;
import android.graphics.PorterDuff;
import android.os.Build;
import android.os.CountDownTimer;
import android.os.Environment;
import android.os.Handler;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.text.Editable;
import android.text.InputType;
import android.text.TextWatcher;
import android.util.Log;
import android.view.KeyEvent;
import android.view.View;
import android.view.WindowManager;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.HashMap;
import java.util.Objects;

public class ActivityApp extends AppCompatActivity {
    private static ImageView dialog_panel_delete, dialog_panel_change_pass,
            back_smooth, eye_old_pass, eye_new_pass, eye_check_pass, dialog_panel_load_backup;
    private static TextView text_dialog_delete, warning_text_dialog, warning_text_load_backup;
    private static EditText old_pass, new_pass, check_pass;
    private static Button btn_yes, btn_no, btn_change, btn_check_pass;

    private static Fragment fragment;

    private File internalStorage;
    private File externalStorage;
    private Intent intentSave;
    private FileNameHelper fileName;

    private boolean changeStatePassword = false;
    private static String colorWhite = "#ffffff";
    private String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
    private static long back_pressed;
    private long timeForClose = 5000;
    private long TIMER;
    private CountDownTimer countDownTimer;
    private CountDownTimer countDownTimerForClose;
    private CountDownTimer countDownTimerForClearClipBoard;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_app);

        //запрет на скриншоты
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE
                , WindowManager.LayoutParams.FLAG_SECURE);
        getWindow().getDecorView().setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);
        getWindow().setSoftInputMode(WindowManager.LayoutParams.SOFT_INPUT_ADJUST_PAN);

        internalStorage = getFilesDir();
        externalStorage = Environment.getExternalStorageDirectory();
        fileName = new FileNameHelper();
        intentSave = getIntent();

        TimerStart();

        fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_list_account);

        dialog_panel_delete = findViewById(R.id.dialog_panel);
        text_dialog_delete = findViewById(R.id.text_dialog);
        btn_yes = findViewById(R.id.btn_dialog_yes);
        btn_no = findViewById(R.id.btn_dialog_no);

        dialog_panel_change_pass = findViewById(R.id.dialog_panel_change_pass);
        back_smooth = findViewById(R.id.back_smooth);
        old_pass = findViewById(R.id.edit_old_pass);
        new_pass = findViewById(R.id.edit_new_pass);
        btn_change = findViewById(R.id.btn_change_password);
        eye_old_pass = findViewById(R.id.eye_old_pass);
        eye_new_pass = findViewById(R.id.eye_new_pass);
        warning_text_dialog = findViewById(R.id.warning_text);

        dialog_panel_load_backup = findViewById(R.id.dialog_panel_load_backup);
        check_pass = findViewById(R.id.checkPassword);
        warning_text_load_backup = findViewById(R.id.warningTextLoadBackup);
        eye_check_pass = findViewById(R.id.eye_check_password);
        btn_check_pass = findViewById(R.id.btn_load_backup);

        dialog_panel_change_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RestartTimer();
                new KeyBoardHelper().KeyBoardHide(ActivityApp.this, old_pass);
                new KeyBoardHelper().KeyBoardHide(ActivityApp.this, new_pass);
            }
        });

        dialog_panel_load_backup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RestartTimer();
                new KeyBoardHelper().KeyBoardHide(ActivityApp.this, check_pass);
            }
        });

        old_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @SuppressLint("ResourceType")
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                RestartTimer();

                if (s.length() > 0)
                    eye_old_pass.setVisibility(View.VISIBLE);
                else
                    eye_old_pass.setVisibility(View.GONE);

                if (old_pass.getText().toString().contains(" "))
                    old_pass.getBackground().setColorFilter
                            (Color.parseColor(getResources().getString(R.color.colorRed)),
                                    PorterDuff.Mode.SRC_ATOP);
                else
                    old_pass.getBackground().setColorFilter
                            (Color.parseColor(getResources().getString(R.color.colorTextWhite)),
                                    PorterDuff.Mode.SRC_ATOP);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        check_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @SuppressLint("ResourceType")
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                RestartTimer();

                if (s.length() > 0)
                    eye_check_pass.setVisibility(View.VISIBLE);
                else
                    eye_check_pass.setVisibility(View.GONE);

                if (check_pass.getText().toString().contains(" "))
                    check_pass.getBackground().setColorFilter
                            (Color.parseColor(getResources().getString(R.color.colorRed)),
                                    PorterDuff.Mode.SRC_ATOP);
                else
                    check_pass.getBackground().setColorFilter
                            (Color.parseColor(getResources().getString(R.color.colorTextWhite)),
                                    PorterDuff.Mode.SRC_ATOP);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        eye_check_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RestartTimer();
                if (check_pass.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    check_pass.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_check_pass.setImageResource(R.drawable.ic_eye_pass_not_look);
                    countDownTimer.cancel();
                } else {
                    check_pass.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    eye_check_pass.setImageResource(R.drawable.ic_eye_pass_look);
                    TimerForPass();
                }
                check_pass.setSelection(check_pass.getText().length());
            }
        });

        eye_old_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RestartTimer();
                if (old_pass.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    old_pass.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_old_pass.setImageResource(R.drawable.ic_eye_pass_not_look);
                    countDownTimer.cancel();
                } else {
                    old_pass.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    eye_old_pass.setImageResource(R.drawable.ic_eye_pass_look);
                    TimerForPass();
                }
                old_pass.setSelection(old_pass.getText().length());
            }
        });

        eye_new_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                RestartTimer();
                if (new_pass.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    new_pass.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_new_pass.setImageResource(R.drawable.ic_eye_pass_not_look);
                    countDownTimer.cancel();
                } else {
                    new_pass.setInputType(InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD);
                    eye_new_pass.setImageResource(R.drawable.ic_eye_pass_look);
                    TimerForPass();
                }
                new_pass.setSelection(new_pass.getText().length());
            }
        });

        new_pass.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {

            }

            @SuppressLint("ResourceType")
            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                RestartTimer();

                if (s.length() > 0)
                    eye_new_pass.setVisibility(View.VISIBLE);
                else
                    eye_new_pass.setVisibility(View.GONE);

                if (new_pass.getText().toString().contains(" "))
                    new_pass.getBackground().setColorFilter
                            (Color.parseColor(getResources().getString(R.color.colorRed)),
                                    PorterDuff.Mode.SRC_ATOP);
                else
                    new_pass.getBackground().setColorFilter
                            (Color.parseColor(getResources().getString(R.color.colorTextWhite)),
                                    PorterDuff.Mode.SRC_ATOP);
            }

            @Override
            public void afterTextChanged(Editable s) {

            }
        });

        btn_change.setOnClickListener(new View.OnClickListener() {
            @SuppressLint("ResourceType")
            @Override
            public void onClick(View v) {
                new KeyBoardHelper().KeyBoardHide(ActivityApp.this, old_pass);
                new KeyBoardHelper().KeyBoardHide(ActivityApp.this, new_pass);
                if (!old_pass.getText().toString().isEmpty()
                        && !new_pass.getText().toString().isEmpty()
                        && !old_pass.getText().toString().contains(" ")
                        && !new_pass.getText().toString().contains(" ")
                        && old_pass.getText().toString().equals(intentSave.getStringExtra("p"))
                        && new_pass.getText().toString().length() >= 8) {
                    changeStatePassword = true;

                    DecryptChangePass(intentSave);
                    Encrypt(new_pass.getText().toString());
                    old_pass.getBackground().setColorFilter
                            (Color.parseColor(getResources().getString(R.color.colorGreen)),
                                    PorterDuff.Mode.SRC_ATOP);
                    new_pass.getBackground().setColorFilter
                            (Color.parseColor(getResources().getString(R.color.colorGreen)),
                                    PorterDuff.Mode.SRC_ATOP);
                    CloseDialogChangePass();

                    new OutputMessage().Message(ActivityApp.this, getResources()
                            .getString(R.string.password_change));

                    Intent intent = new Intent(ActivityApp.this, SignInMenu.class);
                    intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP | Intent.FLAG_ACTIVITY_CLEAR_TASK);
                    startActivity(intent);
                } else {
                    RestartTimer();
                    old_pass.getBackground().setColorFilter
                            (Color.parseColor(getResources().getString(R.color.colorRed)),
                                    PorterDuff.Mode.SRC_ATOP);
                    new_pass.getBackground().setColorFilter
                            (Color.parseColor(getResources().getString(R.color.colorRed)),
                                    PorterDuff.Mode.SRC_ATOP);
                    new OutputMessage().Message(ActivityApp.this, getResources()
                            .getString(R.string.text_error_change_pass));
                }
            }
        });

        btn_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_list_account);
                if (fragment instanceof FragmentListOfAccount)
                    ((FragmentListOfAccount) fragment).DeleteSelectedAccounts();
                else if (fragment instanceof FragmentViewInformation)
                    ((FragmentViewInformation) fragment).DeleteAccount();
                CloseDialogPanel();
            }
        });

        btn_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                CloseDialogPanel();
            }
        });

        if (intentSave.getStringExtra("login") != null && intentSave.getStringExtra("pass") != null) {
            getSupportFragmentManager().beginTransaction()
                    .replace(R.id.fragment_list_account, new FragmentAddAccount())
                    .addToBackStack(null)
                    .commit();
            BtnNavigation();
        }

        btn_check_pass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    BackupInformation information = new BackupInformation(ActivityApp.this);
                    if (information.checkPermission(permission) && DecryptBackupFiles(check_pass.getText().toString())) {
                        new KeyBoardHelper().KeyBoardHide(ActivityApp.this, check_pass);
                        DecryptLocalFiles(intentSave);

                        information.LoadBackup(fileName.getFile_name_sys_ac(), fileName.getFile_name_sys_ic());

                        Encrypt(intentSave);
                        EncryptBackupFiles(check_pass.getText().toString());
                        new OutputMessage().Message(ActivityApp.this, getString(R.string.load_inf_sd));
                        CloseDialogPanelLoadBackup();
                    } else
                        new OutputMessage().Message(ActivityApp.this, getString(R.string.dont_load_inf_sd));
                } catch (Exception e) {
                    Log.d(null, e.getMessage());
                    new OutputMessage().Message(ActivityApp.this, getString(R.string.dont_load_inf_sd));
                }
            }
        });
    }

    @Override
    protected void onStop() {
        if (!Decrypt(intentSave) && !changeStatePassword) {
            Encrypt(intentSave);
        }
        super.onStop();
    }

    @Override
    protected void onResume() {
        RestartTimer();
        executeDelayed();
        super.onResume();
    }

    @Override
    protected void onDestroy() {
        countDownTimerForClose.cancel();
        Log.println(0, "", String.valueOf(new File(internalStorage,
                fileName.getFile_name_save_state()).delete()));
        super.onDestroy();
    }

    @Override
    public boolean onKeyUp(int keyCode, KeyEvent event) {
        switch (keyCode) {
            case KeyEvent.KEYCODE_MENU:
                RestartTimer();
                return false;
        }
        return super.onKeyUp(keyCode, event);
    }

    @Override
    public void onBackPressed() {
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_list_account);

        if (fragment instanceof FragmentListOfAccount) {
            if (back_pressed + 2000 > System.currentTimeMillis()) {
                StopTimer();
                Log.println(0, "", String.valueOf(new File(internalStorage, "saveState").delete()));
                if (!Decrypt(intentSave) && !changeStatePassword) {
                    Encrypt(intentSave);
                }
                moveTaskToBack(true);
                android.os.Process.killProcess(android.os.Process.myPid());
                System.exit(1);
            } else {
                new OutputMessage().Message(this, "Press once again to exit!");
            }
            back_pressed = System.currentTimeMillis();
        } else if (fragment instanceof FragmentListOfIcon) {
            super.onBackPressed();
            RestartTimer();
            BtnNavigation();
        } else if (fragment instanceof FragmentViewInformation) {
            super.onBackPressed();
            RestartTimer();
            BtnNavigation();
        } else if (fragment instanceof FragmentAddAccount) {
            super.onBackPressed();
            FragmentListOfAccount.icon_previewClick = false;
            BtnNavigation();
            Log.println(0, "", String.valueOf(new File(internalStorage, "saveState").delete()));
        } else if (fragment instanceof FragmentSettings) {
            super.onBackPressed();
            BtnNavigation();
        }
    }

    public boolean CheckAnimSettings() {
        try {
            HashMap hashMap = new ObjectStreamHelper()
                    .ObjectInputStream(new File(getFilesDir(), fileName.getFile_name_settings()));

            int b = (int) hashMap.get("anim");
            if (b == 1) {
                return true;
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
        return false;
    }

    public static void CloseDialogPanel() {
        dialog_panel_delete.setVisibility(View.GONE);
        text_dialog_delete.setVisibility(View.GONE);
        btn_yes.setVisibility(View.GONE);
        btn_no.setVisibility(View.GONE);
        back_smooth.setVisibility(View.GONE);
    }

    public static void OpenDialogPanelFromList() {
        dialog_panel_delete.setVisibility(View.VISIBLE);
        text_dialog_delete.setText(R.string.delete_more_accounts);
        text_dialog_delete.setVisibility(View.VISIBLE);
        btn_yes.setVisibility(View.VISIBLE);
        btn_no.setVisibility(View.VISIBLE);
        back_smooth.setVisibility(View.VISIBLE);
    }

    public static void OpenDialogPanelFromView() {
        back_smooth.setVisibility(View.VISIBLE);
        dialog_panel_delete.setVisibility(View.VISIBLE);
        text_dialog_delete.setText(R.string.delete_account);
        text_dialog_delete.setVisibility(View.VISIBLE);
        btn_yes.setVisibility(View.VISIBLE);
        btn_no.setVisibility(View.VISIBLE);
        back_smooth.setVisibility(View.VISIBLE);
    }

    public static void OpenDialogChangePass() {

        back_smooth.setVisibility(View.VISIBLE);
        dialog_panel_change_pass.setVisibility(View.VISIBLE);
        old_pass.setVisibility(View.VISIBLE);
        old_pass.getBackground().setColorFilter
                (Color.parseColor(colorWhite),
                        PorterDuff.Mode.SRC_ATOP);
        new_pass.setVisibility(View.VISIBLE);
        new_pass.getBackground().setColorFilter
                (Color.parseColor(colorWhite),
                        PorterDuff.Mode.SRC_ATOP);
        warning_text_dialog.setVisibility(View.VISIBLE);
        btn_change.setVisibility(View.VISIBLE);
    }

    public static void CloseDialogChangePass() {
        back_smooth.setVisibility(View.GONE);
        dialog_panel_change_pass.setVisibility(View.GONE);
        old_pass.setVisibility(View.GONE);
        new_pass.setVisibility(View.GONE);
        old_pass.setText("");
        new_pass.setText("");
        warning_text_dialog.setVisibility(View.GONE);
        btn_change.setVisibility(View.GONE);
        eye_old_pass.setVisibility(View.GONE);
        eye_new_pass.setVisibility(View.GONE);
    }

    public static void OpenDialogPanelLoadBackup() {
        back_smooth.setVisibility(View.VISIBLE);
        dialog_panel_load_backup.setVisibility(View.VISIBLE);
        warning_text_load_backup.setVisibility(View.VISIBLE);
        check_pass.getBackground().setColorFilter
                (Color.parseColor(colorWhite),
                        PorterDuff.Mode.SRC_ATOP);
        check_pass.setVisibility(View.VISIBLE);
        eye_check_pass.setVisibility(View.VISIBLE);
        btn_check_pass.setVisibility(View.VISIBLE);
    }

    public static void CloseDialogPanelLoadBackup() {
        back_smooth.setVisibility(View.GONE);
        dialog_panel_load_backup.setVisibility(View.GONE);
        warning_text_load_backup.setVisibility(View.GONE);
        check_pass.setVisibility(View.GONE);
        check_pass.setText("");
        eye_check_pass.setVisibility(View.GONE);
        btn_check_pass.setVisibility(View.GONE);
    }

    private void SetBlurPanel(ImageView background) {
        Bitmap res = BlurBuilder.blur(ActivityApp.this,
                BitmapFactory.decodeResource(getResources(), R.drawable.background_smooth));
        background.setImageBitmap(res);
    }

    private void TimerForPass() {
        countDownTimer = new CountDownTimer(timeForClose, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                if (check_pass.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    check_pass.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_check_pass.setImageResource(R.drawable.ic_eye_pass_not_look);
                }
                check_pass.setSelection(check_pass.getText().length());

                if (old_pass.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    old_pass.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_old_pass.setImageResource(R.drawable.ic_eye_pass_not_look);
                }
                old_pass.setSelection(old_pass.getText().length());

                if (new_pass.getInputType() == InputType.TYPE_TEXT_VARIATION_VISIBLE_PASSWORD) {
                    new_pass.setInputType(InputType.TYPE_CLASS_TEXT |
                            InputType.TYPE_TEXT_VARIATION_PASSWORD);
                    eye_new_pass.setImageResource(R.drawable.ic_eye_pass_not_look);
                }
                new_pass.setSelection(new_pass.getText().length());
            }
        }.start();
    }

    public void TimerClearClipBoard() {
        countDownTimerForClearClipBoard = new CountDownTimer(60000, 1000) {
            ClipboardManager clipboardManager = (ClipboardManager) getSystemService(Context.CLIPBOARD_SERVICE);
            ClipData clipData;

            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                for (int i = 0; i < 50; i++) {
                    clipData = ClipData.newPlainText(null, null);
                    clipboardManager.setPrimaryClip(clipData);
                }

            }
        }.start();
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public void TimerStart() {
        try {
            HashMap hashMap = new ObjectStreamHelper()
                    .ObjectInputStream(new File(internalStorage, fileName.getFile_name_settings()));

            TIMER = (int) hashMap.get("time") * 60000;
        } catch (Exception e) {
            e.printStackTrace();
        }

        countDownTimerForClose = new CountDownTimer(TIMER, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                try {
                    Fragment fragment_ = getSupportFragmentManager().findFragmentById(R.id.fragment_list_account);

                    if (fragment_ instanceof FragmentListOfIcon) {
                        onBackPressed();
                    }

                    if (!Decrypt(intentSave) && !changeStatePassword) {
                        Encrypt(intentSave);
                    }

                    fragment_ = getSupportFragmentManager().findFragmentById(R.id.fragment_list_account);

                    if (fragment_ instanceof FragmentAddAccount) {
                        Log.println(0, "", String.valueOf
                                (new File(internalStorage, fileName.getFile_name_save_fields()).delete()));
                        Intent intent = new Intent(ActivityApp.this, SignInMenu.class);
                        intent.putExtra("login", ((EditText) findViewById(R.id.fr_edit_login)).getText().toString());
                        intent.putExtra("pass", ((EditText) findViewById(R.id.fr_edit_pass)).getText().toString());

                        if (FragmentAddAccount.getBundle != null) {
                            intent.putExtra(fileName.getIntentExtraName(),
                                    FragmentAddAccount.getBundle.getString(fileName.getIntentExtraName()));
                            intent.putExtra(fileName.getIntentExtraIcon(),
                                    FragmentAddAccount.getBundle.getInt(fileName.getIntentExtraIcon(), R.drawable.ic_security));
                        } else if (FragmentAddAccount.getSaveState) {
                            HashMap map = new ObjectStreamHelper()
                                    .ObjectInputStream(new File(internalStorage, "saveState"));
                            intent.putExtra(fileName.getIntentExtraName(),
                                    String.valueOf(map.get(fileName.getIntentExtraName())));
                            intent.putExtra(fileName.getIntentExtraIcon(),
                                    Integer.valueOf(Objects.requireNonNull(map.get("resource")).toString()));
                            Log.println(0, "",
                                    String.valueOf(new File(internalStorage, "saveState").delete()));
                        } else {
                            intent.putExtra(fileName.getIntentExtraName(),
                                    intentSave.getStringExtra(fileName.getIntentExtraName()));
                            intent.putExtra(fileName.getIntentExtraIcon(),
                                    intentSave.getIntExtra(fileName.getIntentExtraIcon(), R.drawable.ic_security));
                        }
                        intent.putExtra("changeState", FragmentAddAccount.changeState);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    } else {
                        Intent intent = new Intent(ActivityApp.this, SignInMenu.class);
                        intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TASK);
                        startActivity(intent);
                    }
                } catch (Exception e) {
                    e.getStackTrace();
                }
            }
        }.start();
    }

    public void StopTimer() {
        countDownTimerForClose.cancel();
    }

    public void RestartTimer() {
        countDownTimerForClose.cancel();
        TimerStart();
    }

    @SuppressLint("ObsoleteSdkInt")
    public void SetFragmentBackground(ConstraintLayout layout, CoordinatorLayout coordinatorLayout, int res) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            layout.setBackgroundResource(res);
            coordinatorLayout.setBackgroundResource(res);
            ChangeThemeApplication(res);
        }
    }

    public void BtnNavigation() {
        FragmentNavigationMenu fragmentNavigationMenu = (FragmentNavigationMenu) getSupportFragmentManager()
                .findFragmentById(R.id.fragment_navigation_menu);
        Fragment fragment = getSupportFragmentManager().findFragmentById(R.id.fragment_list_account);
        assert fragmentNavigationMenu != null;
        findViewById(R.id.fragment_navigation_menu).setVisibility(View.VISIBLE);

        if (fragment instanceof FragmentListOfAccount) {
            fragmentNavigationMenu.navigation_home.setBackgroundResource(R.drawable.button_navigation_style);
            fragmentNavigationMenu.navigation_add_new_account.setBackgroundResource(R.drawable.button_time_style);
            fragmentNavigationMenu.navigation_settings.setBackgroundResource(R.drawable.button_time_style);
        }

        if (fragment instanceof FragmentAddAccount) {
            fragmentNavigationMenu.navigation_home.setBackgroundResource(R.drawable.button_time_style);
            fragmentNavigationMenu.navigation_add_new_account.setBackgroundResource(R.drawable.button_navigation_style);
            fragmentNavigationMenu.navigation_settings.setBackgroundResource(R.drawable.button_time_style);
        }

        if (fragment instanceof FragmentSettings) {
            fragmentNavigationMenu.navigation_home.setBackgroundResource(R.drawable.button_time_style);
            fragmentNavigationMenu.navigation_add_new_account.setBackgroundResource(R.drawable.button_time_style);
            fragmentNavigationMenu.navigation_settings.setBackgroundResource(R.drawable.button_navigation_style);
        }
    }

    public void ChangeThemeApplication(int n) {
        switch (n) {
            case 1: {
                super.setTheme(R.style.themeFirst);
                break;
            }
            case 2: {
                super.setTheme(R.style.themeSecond);
                break;
            }
            case 3: {
                super.setTheme(R.style.themeThird);
                break;
            }
            case 4: {
                super.setTheme(R.style.themeFour);
                break;
            }
            case 5: {
                super.setTheme(R.style.themeFive);
                break;
            }
            case R.drawable.first_gradient: {
                super.setTheme(R.style.themeFirst);
                break;
            }
            case R.drawable.second_gradient: {
                super.setTheme(R.style.themeSecond);
                break;
            }
            case R.drawable.third_gradient: {
                super.setTheme(R.style.themeThird);
                break;
            }
            case R.drawable.four_gradient: {
                super.setTheme(R.style.themeFour);
                break;
            }
            case R.drawable.five_gradient: {
                super.setTheme(R.style.themeFive);
                break;
            }
        }
    }

    private void Encrypt(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");
        try {
            security.Encrypt(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()));
            File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
            Log.d("RenameFromEncrypt", String.valueOf(fr.renameTo
                    (new File(internalStorage, fileName.getFile_name_sys_ac())))) ;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void Encrypt(String pass) {
        Security security = new Security();
        try {
            security.Encrypt(
                    pass, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()));
            File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
            Log.d("RenameFromEncrypt", String.valueOf(fr.renameTo
                    (new File(internalStorage, fileName.getFile_name_sys_ac())))) ;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void EncryptBackupFiles(String pass) {
        Security security = new Security();
        try {
            security.Encrypt(
                    pass, new File(externalStorage, fileName.getBackup_directory_name()
                            + "/" + fileName.getFile_name_sys_ac()),
                    new File(externalStorage, fileName.getBackup_directory_name()
                            + "/" + fileName.getFile_name_sys_ac() + "s"),
                    new File(externalStorage, fileName.getBackup_directory_name()
                            + "/" + fileName.getFile_name_sys_iv()));
            File fr = new File(externalStorage, fileName.getBackup_directory_name()
                    + "/" + fileName.getFile_name_sys_ac() + "s");
            Log.d("RenameFromEncrypt", String.valueOf(fr.renameTo
                    (new File(externalStorage, fileName.getBackup_directory_name()
                    + "/" + fileName.getFile_name_sys_ac())))) ;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void DecryptChangePass(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");
        try {
            if (security.Decrypt(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()))) {
                File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
                Log.d("RenameFromDecrypt", String.valueOf(fr.renameTo
                        (new File(internalStorage, fileName.getFile_name_sys_ac())))) ;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void DecryptLocalFiles(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");
        try {
            if (security.Decrypt(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()))) {
                File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
                Log.d("RenameFromDecrypt", String.valueOf(fr.renameTo
                        (new File(internalStorage, fileName.getFile_name_sys_ac())))) ;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private boolean DecryptBackupFiles(String pass) {
        try {
            if (new Security().Decrypt(
                    pass, new File(externalStorage, fileName.getBackup_directory_name()
                            + "/" + fileName.getFile_name_sys_ac()),
                    new File(externalStorage, fileName.getBackup_directory_name()
                            + "/" + fileName.getFile_name_sys_ac() + "s"),
                    new File(externalStorage, fileName.getBackup_directory_name()
                            + "/" + fileName.getFile_name_sys_iv()))) {
                File fr = new File(externalStorage, fileName.getBackup_directory_name()
                        + "/" + fileName.getFile_name_sys_ac() + "s");
                Log.d("RenameFromDecrypt", String.valueOf(fr.renameTo
                        (new File(externalStorage, fileName.getBackup_directory_name() +
                                "/" + fileName.getFile_name_sys_ac())))) ;
                return true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    private boolean Decrypt(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");

        try {
            if (security.DecryptForSign(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv())))
                return true;
        } catch (Exception e) {
            e.printStackTrace();
        }
        return false;
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        executeDelayed();
    }

    private void executeDelayed() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            public void run() {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }
        }, 200);
    }
}