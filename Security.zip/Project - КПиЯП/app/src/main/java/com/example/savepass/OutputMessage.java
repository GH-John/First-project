package com.example.savepass;

import android.app.Activity;
import android.widget.Toast;

public class OutputMessage {
    public void Message(Activity activity, String text) {
        Toast toast = Toast.makeText(activity.getApplicationContext(),
                text,
                Toast.LENGTH_SHORT);
        toast.show();
    }
}