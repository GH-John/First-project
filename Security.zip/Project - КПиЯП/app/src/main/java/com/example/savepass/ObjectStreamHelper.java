package com.example.savepass;

import android.util.Log;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.HashMap;

public class ObjectStreamHelper {
    public HashMap ObjectInputStream(File file) {
        try (ObjectInputStream input = new ObjectInputStream(new FileInputStream(file))) {
            HashMap map;
            map = (HashMap) input.readObject();
            return map;
        } catch (IOException e) {
            e.printStackTrace();
            Log.d("ObjectInputStream - ", e.getMessage());
        } catch (ClassNotFoundException e) {
            e.printStackTrace();
            Log.d("ObjectInputStream - ", e.getMessage());
        }
        return null;
    }

    public void ObjectOutputStream(HashMapDirectory hashMapDirectory, File file) {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(file))) {
            output.writeObject((HashMap)hashMapDirectory.stringHashMap);
        } catch (IOException e) {
            Log.d("ObjectOutputStream - ", e.getMessage());
        }
    }

    public void ObjectOutputStreamIcon(HashMapDirectory hashMapDirectory, File file) {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(file))) {
            output.writeObject((HashMap)hashMapDirectory.integerHashMap);
        } catch (IOException e) {
            Log.d("ObjectOutputStreamIcon", e.getMessage());
        }
    }

    public void ObjectOutputStreamSettings(HashMapDirectory hashMapDirectory, File file) {
        try (ObjectOutputStream output = new ObjectOutputStream(new FileOutputStream(file))) {
            output.writeObject((HashMap)hashMapDirectory.integerHashMap);
        } catch (IOException e) {
            Log.d("ObjectOutputStreamSet", e.getMessage());
        }
    }

    public void RemoveValuesFromHashMap(File fileAC, File fileIC, String keyMap) {
        try {
            HashMap mapAC = ObjectInputStream(fileAC);
            HashMap mapIC = ObjectInputStream(fileIC);
            if(mapAC.containsKey(keyMap) && mapIC.containsKey(keyMap)) {
                mapAC.remove(keyMap);
                mapIC.remove(keyMap);
                HashMapDirectory directory = new HashMapDirectory();
                directory.stringHashMap = mapAC;
                directory.integerHashMap = mapIC;
                ObjectOutputStream(directory, fileAC);
                ObjectOutputStreamIcon(directory, fileIC);
            }
        } catch (Throwable e) {
            Log.d("RemoveValuesFromHashMap", e.getMessage());
        }
    }
}