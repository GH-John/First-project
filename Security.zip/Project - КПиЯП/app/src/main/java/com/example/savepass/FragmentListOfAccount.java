package com.example.savepass;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.support.annotation.NonNull;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.support.v7.widget.LinearLayoutManager;
import android.support.v7.widget.RecyclerView;
import android.text.Editable;
import android.text.TextWatcher;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.view.inputmethod.InputMethodManager;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import java.io.File;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Objects;

public class FragmentListOfAccount extends Fragment implements View.OnTouchListener {
    private static EditText edit_search;
    private ImageView search_line;
    private static ImageView icon_preview;
    private static ImageView loupe_ico, btn_back, btn_delete, btn_copy, btn_select_all;
    private static TextView text_preview;
    private ConstraintLayout layout;
    private CoordinatorLayout coordinatorLayout;

    private File file;
    private FileNameHelper fileName;
    private File fileIcon;
    private File internalStorage;

    private Intent intentSave;
    private boolean stateEncrypt = false;

    public static boolean fragmentVisible = false;
    private boolean selectAllClick = false;
    public static boolean icon_previewClick = false;

    private ClipboardManager clipboardManager;
    private ClipData clipData;

    private RecyclerView list_account_;
    private List<State> states = new ArrayList();
    private List<State> statesIcon = new ArrayList();
    private List<String> statesName = new ArrayList();

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {

        View view = inflater.inflate(R.layout.fragment_list_of_account, container, false);

        internalStorage = Objects.requireNonNull(getActivity()).getFilesDir();
        fileName = new FileNameHelper();

        intentSave = getActivity().getIntent();

        text_preview = view.findViewById(R.id.fr_text_preview);

        icon_preview = view.findViewById(R.id.fr_icon_preview);

        edit_search = view.findViewById(R.id.fr_edit_search);

        loupe_ico = view.findViewById(R.id.fr_loupe_ico);

        search_line = view.findViewById(R.id.fr_search_line);

        btn_back = view.findViewById(R.id.btn_back_panel);

        btn_delete = view.findViewById(R.id.btn_delete);

        btn_copy = view.findViewById(R.id.btn_copy);

        btn_select_all = view.findViewById(R.id.btn_select_all);

        list_account_ = view.findViewById(R.id.fr_list_account);

        list_account_.setOnTouchListener(this);

        layout = view.findViewById(R.id.fr_list_account_activity);

        coordinatorLayout = view.findViewById(R.id.fr_coordinator_layout);

        edit_search.clearFocus();

        Decrypt(intentSave);

        setInitialData();
        setInitialDataIcon();
        BackgroundUpdate();

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Decrypt(intentSave);

                btn_back.setVisibility(View.GONE);
                btn_delete.setVisibility(View.GONE);
                btn_copy.setVisibility(View.GONE);
                btn_select_all.setVisibility(View.GONE);

                loupe_ico.setVisibility(View.VISIBLE);
                edit_search.setVisibility(View.VISIBLE);

                setInitialData();
                setInitialDataIcon();

                Log.d("Rename", String.valueOf(new File(internalStorage,
                        fileName.getFile_name_accounts_for_delete()).delete()));

                Encrypt(intentSave);
            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityApp.OpenDialogPanelFromList();
            }
        });

        btn_copy.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    String pass = "";

                    Decrypt(intentSave);

                    HashMap mapSelect = new ObjectStreamHelper().ObjectInputStream
                            (new File(internalStorage, fileName.getFile_name_accounts_for_delete()));
                    HashMap mapName = new ObjectStreamHelper().ObjectInputStream
                            (new File(internalStorage, fileName.getFile_name_sys_ac()));

                    for (String nickName : (Iterable<String>) mapSelect.keySet()) {
                        pass = Objects.requireNonNull(mapName.get(nickName)).toString();
                    }

                    clipboardManager = (ClipboardManager) Objects.requireNonNull(getActivity())
                            .getSystemService(Context.CLIPBOARD_SERVICE);
                    clipData = ClipData.newPlainText("", pass);
                    clipboardManager.setPrimaryClip(clipData);
                    Toast.makeText(getActivity().getBaseContext(), getResources().getString(R.string.copied),
                            Toast.LENGTH_SHORT).show();
                    ((ActivityApp) getActivity()).TimerClearClipBoard();
                    Encrypt(intentSave);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        btn_select_all.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (!selectAllClick) {
                    selectAllClick = true;

                    HashMap map = new ObjectStreamHelper().ObjectInputStream
                            (new File(internalStorage, fileName.getFile_name_accounts_for_delete()));

                    if (states.size() == map.size())
                        selectAllClick = false;
                    else
                        btn_copy.setVisibility(View.GONE);

                    list_account_.setAdapter(new RecyclerViewAdapter(FragmentListOfAccount.this,
                            R.layout.patern_recycler_view_icon, states, selectAllClick));
                } else {
                    selectAllClick = false;

                    btn_back.setVisibility(View.GONE);
                    btn_delete.setVisibility(View.GONE);
                    btn_copy.setVisibility(View.GONE);
                    btn_select_all.setVisibility(View.GONE);
                    loupe_ico.setVisibility(View.VISIBLE);
                    edit_search.setVisibility(View.VISIBLE);

                    list_account_.setAdapter(new RecyclerViewAdapter(FragmentListOfAccount.this,
                            R.layout.patern_recycler_view_icon, states, selectAllClick));
                }
                list_account_.setLayoutManager(new LinearLayoutManager(getActivity()));
            }
        });

        icon_preview.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
                file = new File(internalStorage, fileName.getFile_name_sys_ac());

                if (!file.exists() || (edit_search.getText().toString().equals("") && states.size() == 0) && !icon_previewClick) {
                    try {
                        icon_previewClick = true;
                        if (!((ActivityApp) getActivity()).CheckAnimSettings()) {
                            Objects.requireNonNull(getFragmentManager()).beginTransaction()
                                    .setCustomAnimations(R.anim.enter_left_to_right,
                                            R.anim.exit_left_to_right, R.anim.enter_right_to_left,
                                            R.anim.exit_right_to_left)
                                    .replace(R.id.fragment_list_account, new FragmentAddAccount())
                                    .addToBackStack(null)
                                    .commit();
                        } else {
                            Objects.requireNonNull(getFragmentManager()).beginTransaction()
                                    .replace(R.id.fragment_list_account, new FragmentAddAccount())
                                    .addToBackStack(null)
                                    .commit();
                        }
                    } catch (Exception e) {
                        e.getStackTrace();
                    }
                }
            }
        });

        loupe_ico.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
                new KeyBoardHelper().KeyBoardHide(getActivity(), edit_search);
            }
        });

        edit_search.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                if (fragmentVisible)
                    ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
                else
                    new KeyBoardHelper().KeyBoardHide(getActivity(), edit_search);
            }
        });

        edit_search.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence s, int start, int count, int after) {
            }

            @Override
            public void onTextChanged(CharSequence s, int start, int before, int count) {
                if (fragmentVisible) {
                    ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();

                    if (edit_search.length() > 0) {
                        if (!stateEncrypt) {
                            Decrypt(intentSave);
                        }
                        setInitialDataForSearch(edit_search.getText().toString());
                    } else {
                        if (stateEncrypt) {
                            setInitialData();
                            Encrypt(intentSave);
                        } else {
                            Decrypt(intentSave);
                            setInitialData();
                            Encrypt(intentSave);
                        }
                    }
                } else
                    new KeyBoardHelper().KeyBoardHide(getActivity(), edit_search);
            }

            @Override
            public void afterTextChanged(Editable s) {
            }
        });

        edit_search.setOnFocusChangeListener(new View.OnFocusChangeListener() {
            @Override
            public void onFocusChange(View view, boolean focused) {
                if (fragmentVisible) {
                    ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
                    InputMethodManager keyboard = (InputMethodManager) getActivity()
                            .getSystemService(Context.INPUT_METHOD_SERVICE);
                    if (focused)
                        keyboard.showSoftInput(edit_search, 0);
                    else {
                        keyboard.hideSoftInputFromWindow(edit_search.getWindowToken(), 0);
                        edit_search.clearFocus();
                    }
                } else
                    new KeyBoardHelper().KeyBoardHide(getActivity(), edit_search);
            }
        });

        search_line.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
            }
        });

        return view;
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    @Override
    public void onActivityCreated(Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        Encrypt(intentSave);

        PanelGone();

        BackgroundUpdate();
    }

    @Override
    public void onResume() {
        BackgroundUpdate();
        fragmentVisible = true;
        icon_previewClick = false;
        if (!edit_search.getText().toString().equals("")) {
            Decrypt(intentSave);

            setInitialData();
            setInitialDataIcon();
        }
        super.onResume();
    }

    @Override
    public void onPause() {
        super.onPause();
        fragmentVisible = false;
    }

    @Override
    public void onStart() {
        BackgroundUpdate();
        fragmentVisible = true;
        Objects.requireNonNull(getActivity()).findViewById(R.id.fragment_navigation_menu)
                .setVisibility(View.VISIBLE);
        ((ActivityApp) getActivity()).BtnNavigation();
        super.onStart();
    }

    private void BackgroundUpdate() {
        try {
            HashMap hashMap = new ObjectStreamHelper().ObjectInputStream
                    (new File(internalStorage, fileName.getFile_name_settings()));
            int select = 1;

            if (hashMap.get("theme") != null)
                select = (int) hashMap.get("theme");

            switch (select) {
                case 1:
                    ((ActivityApp) Objects.requireNonNull(getActivity()))
                            .SetFragmentBackground(layout, coordinatorLayout, R.drawable.first_gradient);
                    break;
                case 2:
                    ((ActivityApp) Objects.requireNonNull(getActivity()))
                            .SetFragmentBackground(layout, coordinatorLayout, R.drawable.second_gradient);
                    break;
                case 3:
                    ((ActivityApp) Objects.requireNonNull(getActivity()))
                            .SetFragmentBackground(layout, coordinatorLayout, R.drawable.third_gradient);
                    break;
                case 4:
                    ((ActivityApp) Objects.requireNonNull(getActivity()))
                            .SetFragmentBackground(layout, coordinatorLayout, R.drawable.four_gradient);
                    break;
                case 5:
                    ((ActivityApp) Objects.requireNonNull(getActivity()))
                            .SetFragmentBackground(layout, coordinatorLayout, R.drawable.five_gradient);
                    break;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void DeleteSelectedAccounts() {
        Decrypt(intentSave);

        HashMap mapForDelete = new ObjectStreamHelper().ObjectInputStream
                (new File(internalStorage, fileName.getFile_name_accounts_for_delete()));
        HashMap mapName = new ObjectStreamHelper().ObjectInputStream
                (new File(internalStorage, fileName.getFile_name_sys_ac()));
        HashMap mapIcon = new ObjectStreamHelper().ObjectInputStream
                (new File(internalStorage, fileName.getFile_name_sys_ic()));

        for (String key : (Iterable<String>) mapForDelete.keySet()) {
            if (mapName.containsKey(key) && mapIcon.containsKey(key)) {
                mapName.remove(key);
                mapIcon.remove(key);
            }
        }

        HashMapDirectory directory = new HashMapDirectory();

        directory.stringHashMap = mapName;
        directory.integerHashMap = mapIcon;

        new ObjectStreamHelper().ObjectOutputStream
                (directory, new File(internalStorage, fileName.getFile_name_sys_ac()));
        new ObjectStreamHelper().ObjectOutputStreamIcon
                (directory, new File(internalStorage, fileName.getFile_name_sys_ic()));

        loupe_ico.setVisibility(View.VISIBLE);

        edit_search.setVisibility(View.VISIBLE);

        btn_back.setVisibility(View.GONE);
        btn_delete.setVisibility(View.GONE);
        btn_copy.setVisibility(View.GONE);
        btn_select_all.setVisibility(View.GONE);

        setInitialDataIcon();

        if (!edit_search.getText().toString().equals(""))
            setInitialDataForSearch(edit_search.getText().toString());
        else
            setInitialData();

        Encrypt(intentSave);

        icon_previewClick = false;

        Log.println(0, "", String.valueOf
                (new File(internalStorage, fileName.getFile_name_accounts_for_delete()).delete()));
    }

    public static void PanelVisible() {
        loupe_ico.setVisibility(View.GONE);
        edit_search.setVisibility(View.GONE);
        btn_back.setVisibility(View.VISIBLE);
        btn_delete.setVisibility(View.VISIBLE);
        btn_copy.setVisibility(View.VISIBLE);
        btn_select_all.setVisibility(View.VISIBLE);
    }

    public static void PanelGone() {
        btn_back.setVisibility(View.GONE);
        btn_delete.setVisibility(View.GONE);
        btn_copy.setVisibility(View.GONE);
        btn_select_all.setVisibility(View.GONE);
        loupe_ico.setVisibility(View.VISIBLE);
        edit_search.setVisibility(View.VISIBLE);
    }

    public static void BtnCopyVisible() {
        btn_copy.setVisibility(View.VISIBLE);
    }

    public static void BtnCopyGone() {
        btn_copy.setVisibility(View.GONE);
    }

    private void setInitialData() {
        try {
            file = new File(internalStorage, fileName.getFile_name_sys_ac());
            fileIcon = new File(internalStorage, fileName.getFile_name_sys_ic());

            if (file.length() > 0 && file.exists()) {
                HashMap map = new ObjectStreamHelper().ObjectInputStream(file);

                HashMap mapIcon = new ObjectStreamHelper().ObjectInputStream(fileIcon);

                states.clear();

                for (String nick_name : (Iterable<String>) map.keySet()) {
                    states.add(new State(nick_name, Integer.valueOf(Objects.requireNonNull
                            (mapIcon.get(nick_name)).toString())));
                }
                list_account_.setAdapter(new RecyclerViewAdapter(FragmentListOfAccount.this,
                        R.layout.patern_recycler_view_icon, states));
                list_account_.setLayoutManager(new LinearLayoutManager(getActivity()));
            }
            if (states.size() == 0) {
                text_preview.setVisibility(View.VISIBLE);
                icon_preview.setVisibility(View.VISIBLE);
                icon_previewClick = false;
            } else {
                text_preview.setVisibility(View.GONE);
                icon_preview.setVisibility(View.GONE);
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    private void setInitialDataIcon() {
        statesIcon = new FragmentListOfIcon().setInitialDataIcon();
    }

    private void setInitialDataForSearch(String edit_search) {
        try {
            file = new File(internalStorage, fileName.getFile_name_sys_ac());
            fileIcon = new File(internalStorage, fileName.getFile_name_sys_ic());

            if (file.length() > 0 && file.exists()) {
                text_preview.setVisibility(View.GONE);
                icon_preview.setVisibility(View.GONE);

                HashMap map = new ObjectStreamHelper().ObjectInputStream(file);

                HashMap mapIcon = new ObjectStreamHelper().ObjectInputStream(fileIcon);

                states.clear();
                statesName.clear();

                for (String nick_name : (Iterable<String>) mapIcon.keySet()) {
                    for (int i = 0; i < statesIcon.size(); i++) {
                        State state = statesIcon.get(i);
                        if (state.getName().toLowerCase().contains(edit_search.toLowerCase())) {
                            if (Integer.valueOf(Objects.requireNonNull
                                    (mapIcon.get(nick_name)).toString()) == state.getImageResource()) {
                                states.add(new State(nick_name, Integer.valueOf(Objects.requireNonNull
                                        (mapIcon.get(nick_name)).toString())));
                                statesName.add(nick_name);
                            }
                        }
                    }
                }

                for (String nick_name : (Iterable<String>) map.keySet()) {
                    if (nick_name.toLowerCase().contains(edit_search.toLowerCase())) {
                        if (states.size() > 0) {
                            for (int i = 0; i < states.size(); i++) {
                                if (!statesName.contains(nick_name)) {
                                    states.add(new State(nick_name, Integer.valueOf(Objects.requireNonNull
                                            (mapIcon.get(nick_name)).toString())));
                                    statesName.add(nick_name);
                                    break;
                                }
                            }
                        } else {
                            states.add(new State(nick_name, Integer.valueOf(Objects.requireNonNull
                                    (mapIcon.get(nick_name)).toString())));
                            statesName.add(nick_name);
                        }
                    }
                }

                list_account_.setAdapter(new RecyclerViewAdapter(FragmentListOfAccount.this,
                        R.layout.patern_recycler_view_icon, states));
                list_account_.setLayoutManager(new LinearLayoutManager(getActivity()));
            }
            if (states.size() == 0) {
                text_preview.setVisibility(View.VISIBLE);
                icon_preview.setVisibility(View.VISIBLE);
                icon_previewClick = false;
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    private void Encrypt(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");
        try {
            security.Encrypt(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()));
            File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
            Log.d("RenameFromDecrypt", String.valueOf(fr.renameTo
                    (new File(internalStorage, fileName.getFile_name_sys_ac())))) ;
            stateEncrypt = false;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void Decrypt(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");
        try {
            if (security.Decrypt(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()))) {
                File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
                Log.d("RenameFromDecrypt", Boolean.valueOf(fr.renameTo
                        (new File(internalStorage, fileName.getFile_name_sys_ac()))).toString());
                stateEncrypt = true;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {

        new KeyBoardHelper().KeyBoardHide(v, event, getActivity(), edit_search);
        return false;
    }
}