package com.example.savepass;

import android.Manifest;
import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.os.Environment;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.util.HashMap;
import java.util.Objects;

public class FragmentSettings extends Fragment implements View.OnTouchListener {
    private Button btn_delete, btn_yes, btn_no, btn_1_min, btn_2_min, btn_5_min,
            first_btn_gradient, second_btn_gradient, third_btn_gradient,
            four_btn_gradient, five_btn_gradient, btn_change,
            btn_save_inf, btn_load_inf;
    private ImageView switch_remove_anim, switch_look_save_load;

    private boolean switch_anim_click = false;
    private boolean switch_look_click = false;

    private ConstraintLayout layout;
    private CoordinatorLayout coordinatorLayout;
    private TextView message_txt;

    private File internalStorage;
    private File externalStorage;
    private FileNameHelper fileName;

    private Intent intentSave;

    private long timeForClear = 2000;
    private String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;
    private CountDownTimer countDownTimerMessage;

    @TargetApi(Build.VERSION_CODES.KITKAT)
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_settings, container, false);

        internalStorage = getActivity().getFilesDir();
        externalStorage = Environment.getExternalStorageDirectory();
        intentSave = getActivity().getIntent();
        fileName = new FileNameHelper();

        message_txt = view.findViewById(R.id.fr_message_txt);

        layout = view.findViewById(R.id.fr_settings_activity);
        coordinatorLayout = view.findViewById(R.id.fr_coordinator_layout);

        first_btn_gradient = view.findViewById(R.id.fr_first_gradient);
        second_btn_gradient = view.findViewById(R.id.fr_second_gradient);
        third_btn_gradient = view.findViewById(R.id.fr_third_gradient);
        four_btn_gradient = view.findViewById(R.id.fr_four_gradient);
        five_btn_gradient = view.findViewById(R.id.fr_five_gradient);

        btn_1_min = view.findViewById(R.id.fr_btn_1_min);
        btn_2_min = view.findViewById(R.id.fr_btn_2_min);
        btn_5_min = view.findViewById(R.id.fr_btn_5_min);
        switch_remove_anim = view.findViewById(R.id.switch_remove_anim);
        btn_change = view.findViewById(R.id.btn_change_pass);
        btn_save_inf = view.findViewById(R.id.btn_save_inf);
        btn_load_inf = view.findViewById(R.id.btn_load_inf);
        switch_look_save_load = view.findViewById(R.id.switch_save_load);

        btn_delete = view.findViewById(R.id.fr_btn_delete);
        btn_yes = view.findViewById(R.id.fr_btn_yes);
        btn_no = view.findViewById(R.id.fr_btn_no);

        view.setOnTouchListener(this);

        switch_remove_anim.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) getActivity()).RestartTimer();
                ActivityApp.CloseDialogChangePass();
                if (switch_anim_click) {
                    switch_remove_anim.setImageResource(R.drawable.ic_off);
                    switch_anim_click = false;
                    SaveSettings("anim", 0);
                } else {
                    switch_remove_anim.setImageResource(R.drawable.ic_on);
                    switch_anim_click = true;
                    SaveSettings("anim", 1);
                }
            }
        });

        switch_look_save_load.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) getActivity()).RestartTimer();
                ActivityApp.CloseDialogChangePass();
                if (switch_look_click) {
                    switch_look_save_load.setImageResource(R.drawable.ic_off);
                    switch_look_click = false;
                    btn_save_inf.setVisibility(View.GONE);
                    btn_load_inf.setVisibility(View.GONE);
                } else {
                    switch_look_save_load.setImageResource(R.drawable.ic_on);
                    switch_look_click = true;
                    btn_save_inf.setVisibility(View.VISIBLE);
                    btn_load_inf.setVisibility(View.VISIBLE);
                }
            }
        });

        btn_save_inf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                BackupInformation information = new BackupInformation(getActivity());

                try {
                    if (information.checkPermission(permission)) {
                        Decrypt(intentSave);
                        HashMapDirectory hmd = new HashMapDirectory();

                        hmd.stringHashMap = new ObjectStreamHelper().ObjectInputStream
                                (new File(internalStorage, fileName.getFile_name_sys_ac()));
                        information.BackupApp(hmd, fileName.getFile_name_sys_ac(), fileName.getFile_name_sys_ic());

                        Encrypt(intentSave);
                        EncryptBackup(intentSave);

                        hmd.integerHashMap = new ObjectStreamHelper().ObjectInputStream
                                (new File(internalStorage, fileName.getFile_name_sys_ic()));
                        information.BackupApp(hmd, fileName.getFile_name_sys_ac(), fileName.getFile_name_sys_ic());

                        new OutputMessage().Message(getActivity(),
                                getResources().getString(R.string.save_inf_sd));
                    }
                } catch (
                        Exception e) {
                    Log.d("btn_save - ", e.getMessage());
                    new OutputMessage().Message(getActivity(),
                            getResources().getString(R.string.dont_save_inf_sd));
                }
            }
        });

        btn_load_inf.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                try {
                    if (new BackupInformation(Objects.requireNonNull(getActivity())).checkPermission(permission))
                        ActivityApp.OpenDialogPanelLoadBackup();
                } catch (Exception e) {
                    Log.d("btn_load - ", e.getMessage());
                    new OutputMessage().Message(getActivity(), getString(R.string.dont_load_inf_sd));
                }
            }
        });

        first_btn_gradient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) getActivity()).RestartTimer();
                ActivityApp.CloseDialogChangePass();
                DefaultBtnDelete();
                ((ActivityApp) getActivity()).SetFragmentBackground
                        (layout, coordinatorLayout, R.drawable.first_gradient);
                SaveSettings("theme", 1);
                ChangeStyleBtnTheme(1);
                ((ActivityApp) getActivity()).ChangeThemeApplication(1);
            }
        });

        second_btn_gradient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) getActivity()).RestartTimer();
                ActivityApp.CloseDialogChangePass();
                DefaultBtnDelete();
                ((ActivityApp) getActivity())
                        .SetFragmentBackground(layout, coordinatorLayout, R.drawable.second_gradient);
                SaveSettings("theme", 2);
                ChangeStyleBtnTheme(2);
                ((ActivityApp) getActivity()).ChangeThemeApplication(2);
            }
        });

        third_btn_gradient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) getActivity()).RestartTimer();
                ActivityApp.CloseDialogChangePass();
                DefaultBtnDelete();
                ((ActivityApp) getActivity())
                        .SetFragmentBackground(layout, coordinatorLayout, R.drawable.third_gradient);
                SaveSettings("theme", 3);
                ChangeStyleBtnTheme(3);
                ((ActivityApp) getActivity()).ChangeThemeApplication(3);
            }
        });

        four_btn_gradient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) getActivity()).RestartTimer();
                ActivityApp.CloseDialogChangePass();
                DefaultBtnDelete();
                ((ActivityApp) getActivity())
                        .SetFragmentBackground(layout, coordinatorLayout, R.drawable.four_gradient);
                SaveSettings("theme", 4);
                ChangeStyleBtnTheme(4);
                ((ActivityApp) getActivity()).ChangeThemeApplication(4);
            }
        });

        five_btn_gradient.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) getActivity()).RestartTimer();
                ActivityApp.CloseDialogChangePass();
                DefaultBtnDelete();
                ((ActivityApp) getActivity())
                        .SetFragmentBackground(layout, coordinatorLayout, R.drawable.five_gradient);
                SaveSettings("theme", 5);
                ChangeStyleBtnTheme(5);
                ((ActivityApp) getActivity()).ChangeThemeApplication(5);
            }
        });

        btn_change.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) getActivity()).RestartTimer();
                DefaultBtnDelete();
                ActivityApp.OpenDialogChangePass();
            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) getActivity()).RestartTimer();
                ActivityApp.CloseDialogChangePass();
                btn_yes.setVisibility(View.VISIBLE);
                btn_no.setVisibility(View.VISIBLE);
                btn_delete.setVisibility(View.INVISIBLE);
            }
        });

        btn_yes.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) getActivity()).RestartTimer();
                try {
                    Decrypt(intentSave);
                    File f = new File(internalStorage, fileName.getFile_name_sys_ac());
                    File f2 = new File(internalStorage, fileName.getFile_name_sys_ic());

                    HashMap mapName = new ObjectStreamHelper().ObjectInputStream(f);
                    HashMap mapIcon = new ObjectStreamHelper().ObjectInputStream(f2);

                    mapName.clear();
                    mapIcon.clear();

                    HashMapDirectory directory = new HashMapDirectory();

                    directory.stringHashMap = mapName;
                    directory.integerHashMap = mapIcon;

                    if (mapName.size() == 0 && mapIcon.size() == 0) {
                        new ObjectStreamHelper().ObjectOutputStream(directory, f);
                        new ObjectStreamHelper().ObjectOutputStream(directory, f2);

                        DefaultBtnDelete();
                        message_txt.setText(getResources().getString(R.string.information_delete_successfully));
                        TimerMessage();
                    } else {
                        message_txt.setText(getResources().getString(R.string.information_deleted));
                        TimerMessage();
                    }
                    Encrypt(intentSave);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        btn_no.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) getActivity()).RestartTimer();
                DefaultBtnDelete();
            }
        });

        btn_1_min.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityApp.CloseDialogChangePass();
                btn_1_min.setBackgroundResource(R.drawable.button_style);
                btn_2_min.setBackgroundResource(R.drawable.button_time_style);
                btn_5_min.setBackgroundResource(R.drawable.button_time_style);
                DefaultBtnDelete();

                try {
                    SaveSettings("time", 1);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ((ActivityApp) getActivity()).RestartTimer();
            }
        });

        btn_2_min.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityApp.CloseDialogChangePass();
                btn_2_min.setBackgroundResource(R.drawable.button_style);
                btn_1_min.setBackgroundResource(R.drawable.button_time_style);
                btn_5_min.setBackgroundResource(R.drawable.button_time_style);
                DefaultBtnDelete();

                try {
                    SaveSettings("time", 2);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ((ActivityApp) getActivity()).RestartTimer();
            }
        });

        btn_5_min.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityApp.CloseDialogChangePass();
                btn_5_min.setBackgroundResource(R.drawable.button_style);
                btn_2_min.setBackgroundResource(R.drawable.button_time_style);
                btn_1_min.setBackgroundResource(R.drawable.button_time_style);
                DefaultBtnDelete();

                try {
                    SaveSettings("time", 5);
                } catch (Exception e) {
                    e.printStackTrace();
                }
                ((ActivityApp) getActivity()).RestartTimer();
            }
        });

        return view;
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        ((ActivityApp) getActivity()).BtnNavigation();

        FragmentListOfAccount.fragmentVisible = false;

        try {
            HashMap hashMap = new ObjectStreamHelper()
                    .ObjectInputStream(new File(internalStorage, fileName.getFile_name_settings()));

            int select = 0;

            if (hashMap.get("anim") != null)
                select = (int) hashMap.get("anim");
            if (select == 1) {
                switch_anim_click = true;
                switch_remove_anim.setImageResource(R.drawable.ic_on);
            } else {
                switch_anim_click = false;
                switch_remove_anim.setImageResource(R.drawable.ic_off);
            }

            select = 1;

            if (hashMap.get("theme") != null)
                select = (int) hashMap.get("theme");

            ChangeStyleBtnTheme(select);
            switch (select) {
                case 1:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.first_gradient);
                    break;
                case 2:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.second_gradient);
                    break;
                case 3:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.third_gradient);
                    break;
                case 4:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.four_gradient);
                    break;
                case 5:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.five_gradient);
                    break;
            }

            int t = 1;

            if (hashMap.get("time") != null)
                t = (int) hashMap.get("time");

            switch (t) {
                case 1:
                    btn_1_min.setBackgroundResource(R.drawable.button_style);
                    btn_2_min.setBackgroundResource(R.drawable.button_time_style);
                    btn_5_min.setBackgroundResource(R.drawable.button_time_style);
                    break;

                case 2:
                    btn_2_min.setBackgroundResource(R.drawable.button_style);
                    btn_1_min.setBackgroundResource(R.drawable.button_time_style);
                    btn_5_min.setBackgroundResource(R.drawable.button_time_style);
                    break;

                case 5:
                    btn_5_min.setBackgroundResource(R.drawable.button_style);
                    btn_2_min.setBackgroundResource(R.drawable.button_time_style);
                    btn_1_min.setBackgroundResource(R.drawable.button_time_style);
                    break;
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
        super.onActivityCreated(savedInstanceState);
    }

    @Override
    public void onPause() {
        ActivityApp.CloseDialogChangePass();
        super.onPause();
    }

    public void ChangeStyleBtnTheme(int selectPos) {
        switch (selectPos) {
            case 1:
                first_btn_gradient.setBackgroundResource(R.drawable.first_btn_gradient_with_stroke);
                second_btn_gradient.setBackgroundResource(R.drawable.second_btn_gradient);
                third_btn_gradient.setBackgroundResource(R.drawable.third_btn_gradient);
                four_btn_gradient.setBackgroundResource(R.drawable.four_btn_gradient);
                five_btn_gradient.setBackgroundResource(R.drawable.five_btn_gradient);
                break;
            case 2:
                first_btn_gradient.setBackgroundResource(R.drawable.first_btn_gradient);
                second_btn_gradient.setBackgroundResource(R.drawable.second_btn_gradient_with_stroke);
                third_btn_gradient.setBackgroundResource(R.drawable.third_btn_gradient);
                four_btn_gradient.setBackgroundResource(R.drawable.four_btn_gradient);
                five_btn_gradient.setBackgroundResource(R.drawable.five_btn_gradient);
                break;
            case 3:
                first_btn_gradient.setBackgroundResource(R.drawable.first_btn_gradient);
                second_btn_gradient.setBackgroundResource(R.drawable.second_btn_gradient);
                third_btn_gradient.setBackgroundResource(R.drawable.third_btn_gradient_with_stroke);
                four_btn_gradient.setBackgroundResource(R.drawable.four_btn_gradient);
                five_btn_gradient.setBackgroundResource(R.drawable.five_btn_gradient);
                break;
            case 4:
                first_btn_gradient.setBackgroundResource(R.drawable.first_btn_gradient);
                second_btn_gradient.setBackgroundResource(R.drawable.second_btn_gradient);
                third_btn_gradient.setBackgroundResource(R.drawable.third_btn_gradient);
                four_btn_gradient.setBackgroundResource(R.drawable.four_btn_gradient_with_stroke);
                five_btn_gradient.setBackgroundResource(R.drawable.five_btn_gradient);
                break;
            case 5:
                first_btn_gradient.setBackgroundResource(R.drawable.first_btn_gradient);
                second_btn_gradient.setBackgroundResource(R.drawable.second_btn_gradient);
                third_btn_gradient.setBackgroundResource(R.drawable.third_btn_gradient);
                four_btn_gradient.setBackgroundResource(R.drawable.four_btn_gradient);
                five_btn_gradient.setBackgroundResource(R.drawable.five_btn_gradient_with_stroke);
                break;
        }
    }

    private void SaveSettings(String identificator, int number) {
        HashMapDirectory hashMapDirectory = new HashMapDirectory();
        HashMap hashMap = new ObjectStreamHelper()
                .ObjectInputStream(new File(internalStorage, fileName.getFile_name_settings()));
        hashMapDirectory.ParametrsSettingApp(hashMap, identificator, number);
        new ObjectStreamHelper()
                .ObjectOutputStreamSettings(hashMapDirectory, new File(internalStorage, fileName.getFile_name_settings()));
    }

    private void DefaultBtnDelete() {
        btn_delete.setVisibility(View.VISIBLE);
        btn_yes.setVisibility(View.GONE);
        btn_no.setVisibility(View.GONE);
    }

    private void TimerMessage() {
        countDownTimerMessage = new CountDownTimer(timeForClear, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                message_txt.setText("");
            }
        }.start();
    }

    private void Encrypt(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");
        try {
            security.Encrypt(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()));
            File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
            Log.d("RenameFromEncrypt", String.valueOf(fr.renameTo(new File(internalStorage, fileName.getFile_name_sys_ac()))));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void EncryptBackup(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");
        try {
            security.Encrypt(
                    p, new File(externalStorage, fileName.getBackup_directory_name()
                            + "/" + fileName.getFile_name_sys_ac()),
                    new File(externalStorage, fileName.getBackup_directory_name()
                            + "/" + fileName.getFile_name_sys_ac() + "s"),
                    new File(externalStorage, fileName.getBackup_directory_name()
                            + "/" + fileName.getFile_name_sys_iv()));
            File fr = new File(externalStorage, fileName.getBackup_directory_name()
                    + "/" + fileName.getFile_name_sys_ac() + "s");
            Log.d("RenameFromEncrypt", String.valueOf(fr.renameTo(new File(externalStorage, fileName.getBackup_directory_name()
                    + "/" + fileName.getFile_name_sys_ac()))));
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void Decrypt(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");
        try {
            if (security.Decrypt(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()))) {
                File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
                Log.d("RenameFromDecrypt", String.valueOf(fr.renameTo(new File(internalStorage, fileName.getFile_name_sys_ac()))));
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int action = event.getActionMasked();

        ActivityApp.CloseDialogChangePass();
        ActivityApp.CloseDialogPanelLoadBackup();

        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {
            ((ActivityApp) getActivity()).RestartTimer();
            DefaultBtnDelete();
        }
        return false;
    }
}