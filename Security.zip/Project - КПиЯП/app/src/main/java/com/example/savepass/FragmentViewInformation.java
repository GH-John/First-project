package com.example.savepass;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.ClipData;
import android.content.ClipboardManager;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Bundle;
import android.os.CountDownTimer;
import android.support.annotation.NonNull;
import android.support.annotation.Nullable;
import android.support.constraint.ConstraintLayout;
import android.support.design.widget.CoordinatorLayout;
import android.support.v4.app.Fragment;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import java.io.File;
import java.io.FileInputStream;
import java.io.ObjectInputStream;
import java.util.HashMap;
import java.util.Objects;

public class FragmentViewInformation extends Fragment implements View.OnTouchListener {
    private ClipboardManager clipboardManager;
    private ClipData clipData;
    private ImageView btn_back, btn_change_information, btn_delete, btn_copy, account_logo;
    private TextView account_view, password_view, message_text;

    private File file;
    private FileNameHelper fileName;
    private File internalStorage;

    private File fileIcon;

    private Intent intent;
    private Bundle getBundle;
    private long timeForClear = 2000;
    private CountDownTimer countDownTimerMessage;
    private ConstraintLayout layout;
    private CoordinatorLayout coordinatorLayout;

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, ViewGroup container,
                             Bundle savedInstanceState) {
        View view = inflater.inflate(R.layout.fragment_view_information, container, false);

        internalStorage = Objects.requireNonNull(getActivity()).getFilesDir();
        intent = getActivity().getIntent();
        fileName = new FileNameHelper();

        getBundle = getArguments();

        view.setOnTouchListener(this);

        account_view = view.findViewById(R.id.fr_account_view);

        password_view = view.findViewById(R.id.fr_password_view);

        message_text = view.findViewById(R.id.fr_message_text);

        btn_delete = view.findViewById(R.id.fr_btn_delete);

        btn_copy = view.findViewById(R.id.fr_btn_copy);

        btn_back = view.findViewById(R.id.fr_btn_back);

        account_logo = view.findViewById(R.id.fr_account_logo);

        btn_change_information = view.findViewById(R.id.fr_btn_change_information);

        layout = view.findViewById(R.id.fr_view_information_activity);

        coordinatorLayout = view.findViewById(R.id.fr_coordinator_layout);

        getActivity().findViewById(R.id.fragment_navigation_menu).setVisibility(View.GONE);

        Decrypt(intent);

        Thread threadLoad = new Thread(new Runnable() {
            @Override
            public void run() {
                LoadData();
            }
        });

        threadLoad.start();

        account_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
            }
        });

        btn_copy.setOnClickListener(new View.OnClickListener() {
            @TargetApi(Build.VERSION_CODES.P)
            @Override
            public void onClick(View v) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();

                try {
                    String name_account;
                    name_account = getBundle.getString(fileName.getIntentExtraName());

                    Decrypt(intent);
                    file = new File(internalStorage, fileName.getFile_name_sys_ac());

                    ObjectInputStream input = new ObjectInputStream(new FileInputStream(file));

                    HashMap map = (HashMap) input.readObject();
                    String pass = Objects.requireNonNull(map.get(name_account)).toString();

                    clipboardManager = (ClipboardManager) getActivity().getSystemService(Context.CLIPBOARD_SERVICE);
                    clipData = ClipData.newPlainText("", pass);
                    clipboardManager.setPrimaryClip(clipData);
                    message_text.setText(getResources().getString(R.string.copied));
                    TimerMessage();
                    input.close();
                    ((ActivityApp) getActivity()).TimerClearClipBoard();
                    Encrypt(intent);
                } catch (Exception e) {
                    e.printStackTrace();
                }
            }
        });

        btn_back.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
                ((ActivityApp) getActivity()).onBackPressed();
            }
        });

        btn_change_information.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangeInformation();
            }
        });

        account_logo.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ChangeInformation();
            }
        });

        btn_delete.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                ActivityApp.OpenDialogPanelFromView();
            }
        });

        return view;
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);

        FragmentListOfAccount.fragmentVisible = false;

        Objects.requireNonNull(getActivity()).findViewById(R.id.fragment_navigation_menu).setVisibility(View.GONE);

        Encrypt(intent);

        try {
            HashMap hashMap = new ObjectStreamHelper()
                    .ObjectInputStream(new File(internalStorage, fileName.getFile_name_settings()));
            int select = 1;

            if (hashMap.get("theme") != null)
                select = (int) hashMap.get("theme");

            switch (select) {
                case 1:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.first_gradient);
                    break;
                case 2:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.second_gradient);
                    break;
                case 3:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.third_gradient);
                    break;
                case 4:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.four_gradient);
                    break;
                case 5:
                    ((ActivityApp) getActivity()).SetFragmentBackground(layout, coordinatorLayout, R.drawable.five_gradient);
                    break;
            }
        } catch (Exception e) {
            e.getStackTrace();
        }
    }

    @Override
    public void onStart() {
        super.onStart();
        Objects.requireNonNull(getActivity()).findViewById(R.id.fragment_navigation_menu).setVisibility(View.GONE);
    }

    @Override
    public void onResume() {
        super.onResume();
        Objects.requireNonNull(getActivity()).findViewById(R.id.fragment_navigation_menu).setVisibility(View.GONE);
    }

    public void DeleteAccount() {
        ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
        Decrypt(intent);
        new ObjectStreamHelper().RemoveValuesFromHashMap(new File(internalStorage, fileName.getFile_name_sys_ac()),
                new File(internalStorage, fileName.getFile_name_sys_ic()), account_view.getText().toString());

        FragmentListOfAccount fragmentListOfAccount = new FragmentListOfAccount();

        Bundle bundle = new Bundle();
        Bundle bundleGet = getArguments();

        bundle.putString("searchText", Objects.requireNonNull(bundleGet).getString("searchText"));
        fragmentListOfAccount.setArguments(bundle);

        Encrypt(intent);

        assert getFragmentManager() != null;
        getFragmentManager().beginTransaction()
                .replace(R.id.fragment_list_account, fragmentListOfAccount)
                .commit();
    }

    private void ChangeInformation() {
        ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();

        Decrypt(intent);

        fileIcon = new File(internalStorage, fileName.getFile_name_sys_ic());
        HashMap mapIcon = new ObjectStreamHelper().ObjectInputStream(fileIcon);

        FragmentAddAccount fragmentAddAccount = new FragmentAddAccount();

        Bundle bundle = new Bundle();
        Bundle bundleGet = getArguments();

        bundle.putString(fileName.getIntentExtraName(), Objects.requireNonNull(bundleGet)
                .getString(fileName.getIntentExtraName()));
        bundle.putInt(fileName.getIntentExtraIcon(), Integer.valueOf((Objects.requireNonNull
                (mapIcon.get(bundleGet.getString(fileName.getIntentExtraName()))).toString())));
        bundle.putBoolean("clickBtnChange", true);

        fragmentAddAccount.setArguments(bundle);

        Encrypt(intent);

        assert getFragmentManager() != null;
        getFragmentManager().beginTransaction()
                .replace(R.id.fragment_list_account, fragmentAddAccount)
                .addToBackStack(null)
                .commit();
    }

    private void LoadData() {
        try {
            fileIcon = new File(internalStorage, fileName.getFile_name_sys_ic());
            HashMap mIcon = new ObjectStreamHelper().ObjectInputStream(fileIcon);
            account_logo.setImageResource(Integer.valueOf(Objects.requireNonNull
                    (mIcon.get(getBundle.getString(fileName.getIntentExtraName()))).toString()));

            String name_account = getBundle.getString(fileName.getIntentExtraName());

            file = new File(internalStorage, fileName.getFile_name_sys_ac());

            HashMap map = new ObjectStreamHelper().ObjectInputStream(file);

            account_view.setText(name_account);

            password_view.setText(Objects.requireNonNull(map.get(name_account)).toString());
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    public void TimerMessage() {
        countDownTimerMessage = new CountDownTimer(timeForClear, 1000) {
            @Override
            public void onTick(long millisUntilFinished) {

            }

            @Override
            public void onFinish() {
                message_text.setText("");
            }
        }.start();
    }

    private void Encrypt(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");
        try {
            security.Encrypt(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()));
            File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
            Log.d("RenameFileFromEncrypt", String.valueOf(fr.renameTo
                    (new File(internalStorage, fileName.getFile_name_sys_ac())))) ;
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    private void Decrypt(Intent intent) {
        Security security = new Security();
        String p = intent.getStringExtra("p");

        try {
            if (security.Decrypt(
                    p, new File(internalStorage, fileName.getFile_name_sys_ac()),
                    new File(internalStorage, fileName.getFile_name_sys_ac() + "s"),
                    new File(internalStorage, fileName.getFile_name_sys_iv()))) {
                File fr = new File(internalStorage, fileName.getFile_name_sys_ac() + "s");
                Log.d("RenameFileFromDecrypt", String.valueOf(fr.renameTo
                        (new File(internalStorage, fileName.getFile_name_sys_ac())))) ;
            }
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @SuppressLint("ClickableViewAccessibility")
    @Override
    public boolean onTouch(View v, MotionEvent event) {
        int action = event.getActionMasked();

        if (action == MotionEvent.ACTION_DOWN || action == MotionEvent.ACTION_POINTER_DOWN) {

            ((ActivityApp) Objects.requireNonNull(getActivity())).RestartTimer();
        }
        return false;
    }
}