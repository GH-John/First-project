package com.example.savepass;

import android.Manifest;
import android.annotation.TargetApi;
import android.app.Activity;
import android.content.pm.PackageManager;
import android.os.Build;
import android.os.Environment;
import android.support.v4.content.ContextCompat;
import android.util.Log;

import java.io.File;
import java.util.HashMap;

class BackupInformation {
    private Activity activity;
    private File internalStorage;
    private File externalStorage;
    private FileNameHelper fileNameHelper;
    private String permission = Manifest.permission.WRITE_EXTERNAL_STORAGE;

    BackupInformation(Activity activity) {
        this.activity = activity;
        fileNameHelper = new FileNameHelper();
        internalStorage = activity.getFilesDir();
        externalStorage = Environment.getExternalStorageDirectory();
        checkPermission(Manifest.permission.WRITE_EXTERNAL_STORAGE);
    }

    @TargetApi(Build.VERSION_CODES.KITKAT)
    public void BackupApp(HashMapDirectory hmDir, String fileNameAC, String fileNameIC) {
        if (isExternalStorageWritable() && isExternalStorageReadable()
                && checkPermission(permission)) {
            try {
                File file = new File(externalStorage,
                        fileNameHelper.getBackup_directory_name());
                Log.d("Directory creator -", String.valueOf(file.mkdirs()));
                new ObjectStreamHelper().ObjectOutputStream(hmDir,
                        new File(externalStorage,
                                fileNameHelper.getBackup_directory_name() + "/" + fileNameAC));
                new ObjectStreamHelper().ObjectOutputStreamIcon(hmDir, new File(externalStorage,
                        fileNameHelper.getBackup_directory_name() + "/" + fileNameIC));
            } catch (Exception e) {
                Log.d("BackupApp - ", e.getMessage());
            }
        } else {
            new OutputMessage().Message(activity,
                    activity.getResources().getString(R.string.dont_save_inf_sd));
        }
    }

    public void LoadBackup(String fileNameAC, String fileNameIC) {
        try {
            if (isExternalStorageWritable() && isExternalStorageReadable()
                    && checkPermission(permission)) {
                if (SearchBackupFile(fileNameHelper.getFile_name_sys_ac()) &&
                        SearchBackupFile(fileNameHelper.getFile_name_sys_ic()) &&
                        SearchBackupFile(fileNameHelper.getFile_name_sys_iv())) {

                    HashMap mapAC = new ObjectStreamHelper().ObjectInputStream
                            (new File(externalStorage, fileNameHelper.getBackup_directory_name()
                                    + "/" + fileNameAC));
                    HashMap mapIC = new ObjectStreamHelper().ObjectInputStream
                            (new File(externalStorage, fileNameHelper.getBackup_directory_name()
                                    + "/" + fileNameIC));

                    if (mapAC != null && mapIC != null) {
                        HashMapDirectory hmDir = new HashMapDirectory();
                        hmDir.stringHashMap = mapAC;
                        hmDir.integerHashMap = mapIC;
                        new ObjectStreamHelper().ObjectOutputStream(hmDir,
                                new File(internalStorage, fileNameAC));
                        new ObjectStreamHelper().ObjectOutputStreamIcon(hmDir,
                                new File(internalStorage, fileNameIC));
                    }
                } else
                    new OutputMessage().Message(activity, activity.getResources()
                            .getString(R.string.dont_load_inf_sd));
            } else
                new OutputMessage().Message(activity, activity.getResources()
                        .getString(R.string.dont_load_inf_sd));
        } catch (Exception e) {
            Log.d("LoadBackup - ", e.getMessage());
        }
    }

    private boolean SearchBackupFile(String fileName) {
        return new File(externalStorage,
                fileNameHelper.getBackup_directory_name() + "/" + fileName).exists();
    }

    @TargetApi(Build.VERSION_CODES.M)
    public boolean checkPermission(String permission) {
        int check = ContextCompat.checkSelfPermission(activity, permission);
        if (check == PackageManager.PERMISSION_GRANTED)
            return true;
        else {
            activity.requestPermissions(new String[]{permission}, 1);
            return checkPermission(permission);
        }
    }

    private boolean isExternalStorageWritable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state);
    }

    private boolean isExternalStorageReadable() {
        String state = Environment.getExternalStorageState();
        return Environment.MEDIA_MOUNTED.equals(state) ||
                Environment.MEDIA_MOUNTED_READ_ONLY.equals(state);
    }
}