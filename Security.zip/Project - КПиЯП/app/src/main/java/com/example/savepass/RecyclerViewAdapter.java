package com.example.savepass;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.support.v4.app.Fragment;
import android.support.v7.widget.RecyclerView;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.MotionEvent;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.RelativeLayout;
import android.widget.TextView;

import java.io.File;
import java.io.IOException;
import java.security.InvalidAlgorithmParameterException;
import java.security.InvalidKeyException;
import java.security.NoSuchAlgorithmException;
import java.security.spec.InvalidKeySpecException;
import java.util.ArrayList;
import java.util.List;

import javax.crypto.BadPaddingException;
import javax.crypto.IllegalBlockSizeException;
import javax.crypto.NoSuchPaddingException;

public class RecyclerViewAdapter extends RecyclerView.Adapter<RecyclerViewAdapter.ViewHolder> {
    private List<State> records;
    private int layout;
    private static Fragment fragment;
    private boolean selectForDelete = false;
    private boolean selectAll = false;
    private List<String> accountName = new ArrayList<>();
    private FileNameHelper fileName;


    public RecyclerViewAdapter(Fragment fragment, int layout, List<State> records) {
        this.records = records;
        this.layout = layout;
        this.fragment = fragment;
    }

    public RecyclerViewAdapter(Fragment fragment, int layout, List<State> records, boolean selectAll) {
        this.records = records;
        this.layout = layout;
        this.fragment = fragment;
        this.selectAll = selectAll;
    }

    /**
     * Реализация класса ViewHolder, хранящего ссылки на виджеты.
     */
    class ViewHolder extends RecyclerView.ViewHolder {
        private TextView name_icon;
        private ImageView image_icon, background_list;
        private RelativeLayout patern_recycler_icon;

        public ViewHolder(View itemView) {
            super(itemView);
            name_icon = itemView.findViewById(R.id.name_icon);
            image_icon = itemView.findViewById(R.id.image_icon);
            background_list = itemView.findViewById(R.id.background_list);
            patern_recycler_icon = itemView.findViewById(R.id.patern_recycler_icon);
        }
    }

    /**
     * Создание новых View и ViewHolder элемента списка, которые впоследствии могут переиспользоваться.
     */
    @Override
    public ViewHolder onCreateViewHolder(ViewGroup viewGroup, int i) {
        View v = LayoutInflater.from(viewGroup.getContext()).inflate(this.layout, viewGroup, false);
        return new ViewHolder(v);
    }

    /**
     * Заполнение виджетов View данными из элемента списка с номером i
     */
    @SuppressLint("ClickableViewAccessibility")
    @Override
    public void onBindViewHolder(final ViewHolder viewHolder, final int i) {
        final State record = records.get(i);
        final Fragment fragment_ = fragment.getActivity().getSupportFragmentManager()
                .findFragmentById(R.id.fragment_list_account);
        fileName = new FileNameHelper();

        viewHolder.name_icon.setText(record.getName());

        viewHolder.image_icon.setImageResource(record.getImageResource());
        viewHolder.background_list
                .setBackgroundResource(R.drawable.list_account_style);

        if (selectAll && accountName.size() < records.size()) {
            selectForDelete = true;

            if (!accountName.contains(record.getName())) {
                accountName.add(record.getName());
                viewHolder.background_list
                        .setBackgroundResource(R.drawable.list_account_long_press);
            }
            InputFile(fragment_.getActivity().getFilesDir(), accountName);
        } else if (selectAll && accountName.size() == records.size()) {
            accountName.clear();
            FragmentListOfAccount.PanelGone();
            selectAll = false;
            selectForDelete = false;
        } else {
            accountName.clear();
            FragmentListOfAccount.PanelGone();
            selectAll = false;
            selectForDelete = false;
        }

        viewHolder.patern_recycler_icon.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                State selectedState = record;

                if (selectForDelete) {
                    if (accountName.contains(selectedState.getName())) {
                        if (accountName.size() == 1) {
                            FragmentListOfAccount.PanelGone();

                            selectForDelete = false;
                            accountName.remove(selectedState.getName());
                            viewHolder.background_list
                                    .setBackgroundResource(R.drawable.list_account_style);

                            new File(fragment_.getActivity().getFilesDir(),
                                    fileName.getFile_name_accounts_for_delete()).delete();
                        } else {
                            accountName.remove(selectedState.getName());
                            viewHolder.background_list
                                    .setBackgroundResource(R.drawable.list_account_style);
                        }
                    } else {
                        accountName.add(selectedState.getName());
                        viewHolder.background_list
                                .setBackgroundResource(R.drawable.list_account_long_press);
                    }

                    if (accountName.size() > 1)
                        FragmentListOfAccount.BtnCopyGone();
                    if (accountName.size() == 1)
                        FragmentListOfAccount.BtnCopyVisible();

                    InputFile(fragment_.getActivity().getFilesDir(), accountName);
                } else if (fragment_ instanceof FragmentListOfAccount
                        && FragmentListOfAccount.fragmentVisible) {
                    // получаем выбранный пункт

                    ((ActivityApp) fragment.getActivity()).RestartTimer();

                    FragmentViewInformation fragmentViewInformation = new FragmentViewInformation();

                    Bundle bundle = new Bundle();

                    bundle.putString(fileName.getIntentExtraName(), selectedState.getName());

                    Intent intent = fragment_.getActivity().getIntent();

                    Security security = new Security();

                    try {
                        if (!security.DecryptForSign(intent.getStringExtra("p"),
                                new File(fragment_.getActivity().getFilesDir(), fileName.getFile_name_sys_ac()),
                                new File(fragment_.getActivity().getFilesDir(), fileName.getFile_name_sys_ac() + "s"),
                                new File(fragment_.getActivity().getFilesDir(), fileName.getFile_name_sys_iv()))) {
                            security.Encrypt(intent.getStringExtra("p"),
                                    new File(fragment_.getActivity().getFilesDir(), fileName.getFile_name_sys_ac()),
                                    new File(fragment_.getActivity().getFilesDir(), fileName.getFile_name_sys_ac() + "s"),
                                    new File(fragment_.getActivity().getFilesDir(), fileName.getFile_name_sys_iv()));
                            File fr = new File(fragment_.getActivity().getFilesDir(), fileName.getFile_name_sys_ac() + "s");
                            Log.println(0, "",
                                    String.valueOf(fr.renameTo(new File(fragment_.getActivity().getFilesDir(),
                                            fileName.getFile_name_sys_ac()))));
                        }
                    } catch (NoSuchPaddingException e) {
                        e.printStackTrace();
                    } catch (NoSuchAlgorithmException e) {
                        e.printStackTrace();
                    } catch (BadPaddingException e) {
                        e.printStackTrace();
                    } catch (IllegalBlockSizeException e) {
                        e.printStackTrace();
                    } catch (IOException e) {
                        e.printStackTrace();
                    } catch (InvalidAlgorithmParameterException e) {
                        e.printStackTrace();
                    } catch (InvalidKeyException e) {
                        e.printStackTrace();
                    } catch (InvalidKeySpecException e) {
                        e.printStackTrace();
                    }

                    fragmentViewInformation.setArguments(bundle);

                    fragment.getActivity().getSupportFragmentManager().beginTransaction()
                            .replace(R.id.fragment_list_account, fragmentViewInformation)
                            .addToBackStack(null)
                            .commit();
                } else if (fragment_ instanceof FragmentListOfIcon) {
                    ((ActivityApp) fragment.getActivity()).RestartTimer();

                    Bundle getBundle = fragment.getArguments();

                    HashMapDirectory directory = new HashMapDirectory();

                    directory.InputAccount(fileName.getIntentExtraName(),
                            getBundle.getString(fileName.getIntentExtraName()));
                    directory.InputAccount("resource", String.valueOf(selectedState.getImageResource()));
                    directory.InputAccount("changeState",
                            String.valueOf(getBundle.getBoolean("changeState", false)));
                    directory.InputAccount("fields", "true");

                    File f = fragment.getActivity().getFilesDir();

                    new ObjectStreamHelper().ObjectOutputStream(directory,
                            new File(f, "saveState"));

                    fragment.getActivity().onBackPressed();
                }
            }
        });

        viewHolder.patern_recycler_icon.setOnLongClickListener(new View.OnLongClickListener() {
            @Override
            public boolean onLongClick(View v) {
                if (FragmentListOfAccount.fragmentVisible) {
                    State selectedState = record;
                    final Fragment fragment_ = fragment.getActivity().getSupportFragmentManager()
                            .findFragmentById(R.id.fragment_list_account);
                    if (fragment_ instanceof FragmentListOfAccount && !accountName.contains(selectedState.getName())) {
                        accountName.add(selectedState.getName());
                        viewHolder.background_list
                                .setBackgroundResource(R.drawable.list_account_long_press);
                        selectForDelete = true;

                        InputFile(fragment_.getActivity().getFilesDir(), accountName);

                        FragmentListOfAccount.PanelVisible();
                        return true;
                    }
                }
                return false;
            }
        });

        if (fragment_ instanceof FragmentListOfIcon) {
            viewHolder.patern_recycler_icon.setOnTouchListener(new View.OnTouchListener() {
                @Override
                public boolean onTouch(View v, MotionEvent event) {
                    final Fragment fragment_ = fragment.getActivity().getSupportFragmentManager()
                            .findFragmentById(R.id.fragment_list_account);
                    new KeyBoardHelper().KeyBoardHide(v, event, fragment_.getActivity(),
                            ((FragmentListOfIcon) fragment).edit_search_icon);
                    return false;
                }
            });
        }
    }

    @Override
    public int getItemCount() {
        return records.size();
    }

    private void InputFile(File internalStorage, List<String> list) {
        HashMapDirectory directory = new HashMapDirectory();

        for (int i = 0; i < list.size(); i++) {
            directory.InputAccount(list.get(i), list.get(i));
        }

        new ObjectStreamHelper().ObjectOutputStream(directory,
                new File(internalStorage, fileName.getFile_name_accounts_for_delete()));
    }
}