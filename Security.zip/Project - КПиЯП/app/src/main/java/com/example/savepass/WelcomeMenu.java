package com.example.savepass;

import android.annotation.SuppressLint;
import android.annotation.TargetApi;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.support.constraint.ConstraintLayout;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.Button;

import java.io.File;
import java.util.HashMap;

public class WelcomeMenu extends AppCompatActivity {
    private Button btn_registration;
    private ConstraintLayout layout;

    private File file;
    private FileNameHelper fileName;
    private File internalStorage;

    @TargetApi(Build.VERSION_CODES.KITKAT)
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_welcome_menu);

        internalStorage = getFilesDir();
        fileName = new FileNameHelper();
        layout = findViewById(R.id.welcome_menu_activity);

        //запрет на скриншоты
        getWindow().setFlags(WindowManager.LayoutParams.FLAG_SECURE
                , WindowManager.LayoutParams.FLAG_SECURE);

        getWindow().getDecorView()
                .setSystemUiVisibility(View.SYSTEM_UI_FLAG_HIDE_NAVIGATION);

        file = new File(internalStorage, fileName.getFile_name_settings());

        if (!file.exists()) {
            HashMapDirectory hashMapDirectory = new HashMapDirectory();

            hashMapDirectory.ParametrsSettingApp("time", 1);
            hashMapDirectory.ParametrsSettingApp("theme", 3);
            hashMapDirectory.ParametrsSettingApp("anim", 0);
            new ObjectStreamHelper().ObjectOutputStreamSettings(hashMapDirectory,
                    new File(internalStorage, fileName.getFile_name_settings()));
        }

        file = new File(internalStorage, fileName.getFile_name_sys_ac());

        if (file.exists()) {
            Intent intent = new Intent(WelcomeMenu.this, SignInMenu.class);
            startActivity(intent);
        }

        try {
            HashMap hashMap = new ObjectStreamHelper()
                    .ObjectInputStream(new File(internalStorage,
                            fileName.getFile_name_settings()));

            int select = 1;

            if (hashMap.get("theme") != null)
                select = (int) hashMap.get("theme");

            switch (select) {
                case 1:
                    SetLayoutBackground(layout, R.drawable.first_gradient);
                    break;
                case 2:
                    SetLayoutBackground(layout, R.drawable.second_gradient);
                    break;
                case 3:
                    SetLayoutBackground(layout, R.drawable.third_gradient);
                    break;
                case 4:
                    SetLayoutBackground(layout, R.drawable.four_gradient);
                    break;
                case 5:
                    SetLayoutBackground(layout, R.drawable.five_gradient);
                    break;
            }
        } catch (Exception e) {
            e.getStackTrace();
        }

        btn_registration = findViewById(R.id.btn_registration);

        btn_registration.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                Intent intent = new Intent(WelcomeMenu.this
                        , AutorizationInApp.class);
                intent.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP |
                        Intent.FLAG_ACTIVITY_CLEAR_TASK);
                startActivity(intent);
            }
        });
    }

    @Override
    protected void onResume() {
        super.onResume();
        executeDelayed();
    }

    @SuppressLint("ObsoleteSdkInt")
    public void SetLayoutBackground(ConstraintLayout layout, int res) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.JELLY_BEAN) {
            layout.setBackgroundResource(res);
        }
        switch (res) {
            case R.drawable.first_gradient: {
                SetColorStatusBar(R.color.firstStatusBarColor);
                break;
            }
            case R.drawable.second_gradient: {
                SetColorStatusBar(R.color.secondStatusBarColor);
                break;
            }
            case R.drawable.third_gradient: {
                SetColorStatusBar(R.color.thirdStatusBarColor);
                break;
            }
            case R.drawable.four_gradient: {
                SetColorStatusBar(R.color.fourStatusBarColor);
                break;
            }
            case R.drawable.five_gradient: {
                SetColorStatusBar(R.color.fiveStatusBarColor);
                break;
            }
        }
    }

    private void SetColorStatusBar(int id) {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.LOLLIPOP) {
            Window window = getWindow();
            window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
            window.setStatusBarColor(getResources().getColor(id));
        }
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        executeDelayed();
    }

    private void executeDelayed() {
        Handler handler = new Handler();
        handler.postDelayed(new Runnable() {
            @TargetApi(Build.VERSION_CODES.KITKAT)
            @Override
            public void run() {
                getWindow().getDecorView().setSystemUiVisibility(
                        View.SYSTEM_UI_FLAG_HIDE_NAVIGATION
                                | View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY);
            }
        }, 200);
    }
}